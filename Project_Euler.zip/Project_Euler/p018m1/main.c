/*
Maximum path sum I
Problem 18

By starting at the top of the triangle below and moving to adjacent numbers on the row below, the maximum total from top to bottom is 23.

3
7 4
2 4 6
8 5 9 3

That is, 3 + 7 + 4 + 9 = 23.

Find the maximum total from top to bottom of the triangle below:

75
95 64
17 47 82
18 35 87 10
20 04 82 47 65
19 01 23 75 03 34
88 02 77 73 07 63 67
99 65 04 28 06 16 70 92
41 41 26 56 83 40 80 70 33
41 48 72 33 47 32 37 16 94 29
53 71 44 65 25 43 91 52 97 51 14
70 11 33 28 77 73 17 78 39 68 17 57
91 71 52 38 17 14 91 43 58 50 27 29 48
63 66 04 68 89 53 67 30 73 16 69 87 40 31
04 62 98 27 23 09 70 98 73 93 38 53 60 04 23

NOTE: As there are only 16384 routes, it is possible to solve this problem by trying every route. However, Problem 67, is the same challenge with a triangle containing one-hundred rows; it cannot be solved by brute force, and requires a clever method! ;o)
*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

int main()
{
    //Variables
    FILE *f = fopen("p018_numbers.txt","r");
    int numberoflines = 0;//Number of lines.
    int *sizeoflines = NULL;
    int tmp = 0;
    int idx[2] = {0,0};
    char s[10];
    char s2[2] = {'\0','\0'};
    char c;
    int ** triangle = NULL;
    int i = 0, j = 0, k = 0;
    char **direction = NULL;
    char *directiontmp = NULL;
    int *sum = (int*)calloc(17, sizeof(int));

    //Printing input file
    printf("Printing input file:\n");
    fseek(f, 0, SEEK_SET);
    while((c = getc(f)) != EOF) putc(c, stdout);
    printf("\n");

    //Calculating triangle parameter
    numberoflines = 0;
    fseek(f, 0, SEEK_SET);
    while((c = getc(f)) != EOF) if(c == '\n') numberoflines++;
    numberoflines++;
    printf("\nnumberoflines = %d\n",numberoflines);

    //Memory allocation
    triangle = (int**)calloc(numberoflines, sizeof(int*));
    sizeoflines = (int*)calloc(numberoflines, sizeof(int));
    fseek(f, 0, SEEK_SET);
    i = 0;
    tmp = 0;
    c = getc(f);
    while(c != EOF)
    {
        while(c != EOF && c != '\n')
        {
            if(c == ' ') tmp++;
            c = getc(f);
        }
        tmp++;
        sizeoflines[i] = tmp;
        //printf("Line %d\n", __LINE__);
        triangle[i] = (int*)calloc(sizeoflines[i], sizeof(int));
        i++;
        tmp = 0;
        c = getc(f);
    }
    sum = (int*)calloc(sizeoflines[numberoflines-1], sizeof(int));
    printf("sizeoflines[numberoflines-2] = %d, sizeof(int) = %d, size of sum = %d\n", sizeoflines[numberoflines-2], (int)sizeof(int), (int)sizeof(sum));
    direction = (char**)calloc(numberoflines-1, sizeof(char*));
    for(j = 0; j<20; j++) direction[j] = (char*)calloc(sizeoflines[numberoflines-2], sizeof(char));
    printf("size of direction = %d, size of direction[0] = %d\n", (int)sizeof(direction), (int)sizeof(direction[0]));
    printf("numberoflines-1 = %d, size of directiontmp  = %d\n", numberoflines-1,(int)sizeof(directiontmp));

    //Printing array size parameters.
    printf("\n");
    for(i = 0; i<numberoflines; i++) printf("sizeoflines[%d] = %d\n",i, sizeoflines[i]);
    //printf("Line %d\n", __LINE__);

    //Reading input into array
    fseek(f, 0, SEEK_SET);
    i = 0;
    j = 0;
    tmp = 0;
    c = getc(f);
    //Reading file.
    while(c != EOF)
    {
        //printf("Line %d - Running while(c != EOF)\n", __LINE__);
        //Reading line.
        while(!isdigit(c)) c = getc(f);
        while(c != '\n')
        {
            //printf("Line %d - Running while(c != per n)\n", __LINE__);
            while(!isdigit(c)) c = getc(f);
            //Reading a number in line.
            while(isdigit(c))
            {
                //putc(c, stdout);
                s2[0] = c;
                strcat(s,s2);
                c = getc(f);
            }
            //printf("s = %s\n",s);
            triangle[i][j] = atoi(s);
            //printf("triangle[%d][%d] = %d\n", i, j, triangle[i][j]);
            for(k=0; k<10; k++) s[k] = '\0';
            j++;
            if(c == '\n')
            {
                i++;
                j = 0;
            }
            else if(c == EOF)
            {
                break;
            }
            else
            {
                while(!isdigit(c)) c = getc(f);
            }
            //printf("Line %d - End of  while(c != EOF && c !=  per n)\n", __LINE__);
            //printf("c = %c\n",c);
        }
    }
    //printf("Line %d - End of while(c != EOF)\n", __LINE__);

    //Printing the input triangle.
    printf("\nInput triangle:\n");
    for(i = 0; i<numberoflines; i++)
    {
        for(j = 0; j<sizeoflines[i]; j++)
        {
            printf("%2.d ",triangle[i][j]);
        }
        printf("\n");
    }
    printf("\n");

    //Processing triangle
    for(j = 0; j<sizeoflines[numberoflines-1]; j++) sum[j] = triangle[numberoflines-1][j];
    printf("Initial values of sum:\n");
    for(j = 0; j<sizeoflines[numberoflines-1]; j++) printf("%2.d ", sum[j]);
    printf("\n");
    //printf("Line %d\n", __LINE__);

    for(i = numberoflines-2; i>=0; i--)
    {
        //printf("Line %d\n", __LINE__);
        for(j=0; j<sizeoflines[i]; j++)
        {
            //printf("Line %d\n", __LINE__);
            if(sum[j]>=sum[j+1])
            {
                direction[i][j] = '0';
                sum[j] = triangle[i][j]+sum[j];
            }
            else
            {
                direction[i][j] = '1';
                sum[j] = triangle[i][j]+sum[j+1];
                for(k=i+1;k<=numberoflines-2;k++) direction[k][j] = direction[k][j+1];
                //printf("Line %d\n", __LINE__);
            }
        }
    }
    printf("Line %d - Double for end.\n", __LINE__);

    //Printing the results
    printf("\nThe maximum total from top to bottom of the triangle: %d\n\n", sum[0]);
    printf("Direction from top: ");
    for(i=0;i<numberoflines-1;i++) printf("%c",direction[i][0]);
    printf("\n\n");
    printf("The numbers in path:\n");
    idx[0] = 0;
    idx[1] = 0;
    printf("triangle[ %d][ %d] = %d\n", idx[0], idx[1], triangle[idx[0]][idx[1]]);
    tmp = triangle[idx[0]][idx[1]];
    for(i = 0;i<numberoflines-1; i++)
    {
        ++idx[0];
        if(direction[i][0] == '1') ++idx[1];
        tmp += triangle[idx[0]][idx[1]];
        printf("triangle[%2.d][%2.d] = %d\n", idx[0], idx[1], triangle[idx[0]][idx[1]]);
    }
    printf(" = %d", tmp);


    //Freeing memory.
    free(sizeoflines);
    for(i = 0; i<numberoflines; i++) free(triangle[i]);
    free(triangle);
    free(directiontmp);

    return 0;
}

#include <stdlib.h>
#include <stdio.h>
#include "CsM_Math.h"

void CsM_PrimesUntilUll(struct CsM_DynArrUll1D *ptr, ull number)
{
    ull tmp;
    ull i;
    ull j;

    ptr->numbers = (ull *)realloc(ptr->numbers, 3*sizeof(ull));
    ptr->numbers[0] = 2;
    ptr->numbers[1] = 3;

    i = 2;
    j = 0;
    tmp = ptr->numbers[1] + 2;
    while(tmp<=number)
    {
        //printf("i = %llu\n",tmp);
        while(j<i)
        {
            if(tmp%ptr->numbers[j]==0)
            {
                j = 0;
                tmp += 2;
                break;
            }
            else
            {
                j++;
            }
        }
        if(j==i)
        {
            ptr->numbers = (ull *)realloc(ptr->numbers, (i+1)*sizeof(ull));
            ptr->numbers[i++] = tmp;
            j = 0;
            tmp += 2;
        }
    }

    ptr->numbers =  (ull *)realloc(ptr->numbers, (i+1)*sizeof(ull));
    //printf("i = %llu\n",i+1);
    ptr->meret = i+1;

    return;
}

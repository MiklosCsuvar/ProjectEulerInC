/*
Summation of primes
Problem 10

The sum of the primes below 10 is 2 + 3 + 5 + 7 = 17.
Find the sum of all the primes below two million.
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "CsM_Math.h"

int main()
{
    ull limit = 1999999;
    struct CsM_DynArrUll1D primes;
    ull sum;
    long long i;

    primes.meret = 0;
    primes.numbers = NULL;

    CsM_PrimesUntilUll(&primes,limit);

    sum = 0;
    for(i=0;i<primes.meret;i++)
    {
        printf("%lld:%lld\n",primes.meret,i);
        sum += primes.numbers[i];
    }
    printf("Sum of primes under %llu: %llu\n", limit+1, sum);

    free(primes.numbers);
    return 0;
}


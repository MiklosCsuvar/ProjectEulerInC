/*
Maximum path sum II
Problem 67

By starting at the top of the triangle below and moving to adjacent numbers on the row below, the maximum total from top to bottom is 23.

3
7 4
2 4 6
8 5 9 3

That is, 3 + 7 + 4 + 9 = 23.

Find the maximum total from top to bottom in triangle.txt (right click and 'Save Link/Target As...'), a 15K text file containing a triangle with one-hundred rows.

NOTE: This is a much more difficult version of Problem 18. It is not possible to try every route to solve this problem, as there are 299 altogether! If you could check one trillion (1012) routes every second it would take over twenty billion years to check them all. There is an efficient algorithm to solve it. ;o)
*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "CsM_math.h"

int main()
{
    //Variables
    FILE *f = fopen("p067_triangle.txt","r");
    struct CsM_DynArrLld2DGeneral t = {0,NULL,NULL};
    struct CsM_DynArrLld2DGeneral *p;// = &triangle;
    long long tmp = 0;
    int idx[2] = {0,0};
    long long i = 0, j = 0, k = 0;
    char **direction = NULL;
    long long *sum = NULL;

    t = *(CsM_FileToDynArrLld2DGeneral(f));
    //t = *p;
    printf("Line %d - Got pointer\n", __LINE__);
    printf("numberoflines = %lld\n", (long long)t.numberoflines);

    //Memory allocation
    //t = *p;
    sum = (long long*)calloc(t.sizeoflines[t.numberoflines-1], sizeof(long long));
    direction = (char**)calloc(t.numberoflines-1, sizeof(char*));
    //printf("Line %d: Memory allocated\n", __LINE__);
    for(i = 0; i<t.numberoflines-1; i++) direction[i] = (char*)calloc(t.sizeoflines[t.numberoflines-2], sizeof(char));
    //printf("Line %d: Memory allocated\n", __LINE__);
    for(i = 0; i<t.numberoflines; i++) printf("sizeoflines[%lld] = %d\n",i, t.sizeoflines[i]);
    //printf("Line %d: Memory allocated\n", __LINE__);

    //Printing the input triangle.
    printf("\nInput triangle:\n");
    for(i = 0; i<t.numberoflines; i++)
    {
        for(j = 0; j<t.sizeoflines[i]; j++)
        {
            printf("%2.d ",t.number[i][j]);
        }
        printf("\n");
    }
    printf("\n");

    //Processing triangle
    for(j = 0; j<t.sizeoflines[t.numberoflines-1]; j++) sum[j] = t.number[t.numberoflines-1][j];
    printf("Initial values of sum:\n");
    for(j = 0; j<t.sizeoflines[t.numberoflines-1]; j++) printf("%2.d ", sum[j]);
    printf("\n");
    //printf("Line %d\n", __LINE__);

    for(i = t.numberoflines-2; i>=0; i--)
    {
        //printf("Line %d\n", __LINE__);
        for(j=0; j<t.sizeoflines[i]; j++)
        {
            //printf("Line %d\n", __LINE__);
            //printf("i, j = %d, %d, p->sizeoflines[%d] = %d\n", i, j, i, p->sizeoflines[i]);
            if(sum[j]>=sum[j+1])
            {
                direction[i][j] = '0';
                sum[j] = t.number[i][j]+sum[j];
                //printf("Line %d\n", __LINE__);
            }
            else
            {
                direction[i][j] = '1';
                sum[j] = t.number[i][j]+sum[j+1];
                for(k=i+1;k<=t.numberoflines-2;k++) direction[k][j] = direction[k][j+1];
                //printf("Line %d\n", __LINE__);
            }
        }
    }
    //printf("Line %d - Double for end.\n", __LINE__);

    //Printing the results
    printf("\nThe maximum total from top to bottom of the triangle: %d\n\n", sum[0]);
    printf("Direction from top: ");
    for(i=0; i<t.numberoflines-1; i++) printf("%c",direction[i][0]);
    printf("\n\n");
    printf("The numbers in path:\n");
    idx[0] = 0;
    idx[1] = 0;
    printf("triangle[ %d][ %d] = %lld\n", idx[0], idx[1], t.number[idx[0]][idx[1]]);
    tmp = t.number[idx[0]][idx[1]];
    for(i = 0; i<t.numberoflines-1; i++)
    {
        ++idx[0];
        if(direction[i][0] == '1') ++idx[1];
        tmp += t.number[idx[0]][idx[1]];
        printf("triangle[%2.d][%2.d] = %lld\n", idx[0], idx[1], t.number[idx[0]][idx[1]]);
    }
    printf("Total = %lld", tmp);


    //Freeing memory.
    free(sum);
    for(i = 0; i<t.numberoflines-1; i++) free(direction[i]);
    free(direction);
    for(i = 0; i<t.numberoflines; i++) free(t.number[i]);
    free(t.sizeoflines);
    //free(p);

    return 0;
}

#include "CsM_math.h"

ull CsM_PowerUll(ull base, ull power)
{
    ull result = 1;

    while(power-->0) result *= base;

    return result;
}

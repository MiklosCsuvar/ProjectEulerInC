/*
Digit fifth powers
Problem 30

Surprisingly there are only three numbers that can be written as the sum of fourth powers of their digits:

    1634 = 1^4 + 6^4 + 3^4 + 4^4
    8208 = 8^4 + 2^4 + 0^4 + 8^4
    9474 = 9^4 + 4^4 + 7^4 + 4^4

As 1 = 14 is not a sum it is not included.
The sum of these numbers is 1634 + 8208 + 9474 = 19316.
Find the sum of all the numbers that can be written as the sum of fifth powers of their digits.
*/

#include <stdio.h>
#include <stdlib.h>
#include "CsM_math.h"

int main()
{
    int i, exponent;
    long border, remainder, tmp, tmpresult, result;

    border = 999999;
    exponent = 5;
    result = 0;

    //Searching and adding the numbers
    for(i=2; i<=border; i++)
    {
        tmp = i;
        tmpresult=0;
        while(tmp>0)
        {
            remainder = tmp%10;//Calculating last digit
            tmpresult += CsM_PowerUll(remainder,exponent);//Power calculation
            tmp /= 10;//Substracting last digit
        }
        //Adding number to final result
        if(tmpresult == i)
        {
            result+= tmpresult;
            printf("i = %ld, tmpresult = %ld\n",i, tmpresult);
        }
    }

   //Printing out result.
    printf("Sum of %dth powers = %ld",exponent, result);

    return 0;
}


#include <stdio.h>
#include <stdlib.h>
#include "CsM_MathUll.h"

struct CsM_SequenceUll CsM_CollatzUll(ull n)
{
    struct CsM_SequenceUll r;//Result.
    r.meret = 1;
    r.sequence = (ull*)malloc(sizeof(ull));
    r.sequence[0] = n;
    do
    {
        n = (n%2==0)?(n/2):(3*n+1);
        r.meret++;
        r.sequence = (ull*)realloc(r.sequence, r.meret*sizeof(ull));
        r.sequence[r.meret-1] = n;
    }
    while(n>1);

    return r;
}

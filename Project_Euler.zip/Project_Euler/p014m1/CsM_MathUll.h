#ifndef CSM_MATHULL_H_INCLUDED
#define CSM_MATHULL_H_INCLUDED

#define ull unsigned long long

struct CsM_PrimeFactorsUll
{
    ull  meret;
    ull* factor;
    int* power;
};

struct CsM_SequenceUll
{
    ull* sequence;
    ull meret;
};

struct CsM_SequenceUll CsM_CollatzUll(ull);
ull CsM_LeastCommonMultiple(ull*, ull);
ull CsM_MaxUll(ull*, ull);
struct CsM_PrimeFactorsUll CsM_PrimeFactorisationUll(ull, ull*, ull);
ull* CsM_PrimesUntilUll(ull);

#endif // CSM_MATHULL_H_INCLUDED

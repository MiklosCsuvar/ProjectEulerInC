/*
2520 is the smallest number that can be divided by each of the numbers from 1 to 10 without any remainder.
What is the smallest positive number that is evenly divisible by all of the numbers from 1 to 20?
*/

#include <stdio.h>
#include <stdlib.h>

#define ull unsigned long long

struct CsM_PrimeFactorsUll
{
    ull  meret;
    ull* factor;
    int* power;
};

ull* CsM_PrimesUntilUll(ull);
struct CsM_PrimeFactorsUll CsM_PrimeFactorisationUll(ull, ull*, ull);
ull CsM_MaxUll(ull*, ull);
ull CsM_LeastCommonMultiple(ull*, ull);

int main(int argc, char *argv[])
{
    //unsigned long long n = 1000000;
    //ull n = 3780;
    //ull i = 0;
    //struct CsM_PrimeFactorsUll tmp;
    //ull *ptr = '\0';
    ull numbers[20] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20};
    //ull numbers[20] = {1,2,3,3,4,5,3,4,5,3,4,5,3,4,5,3,4,5,3,4};
    ull tmp2;

    //ptr = (ull*)realloc(ptr, 1*sizeof(ull));
    //ptr = CsM_PrimesUntilUll(n);
    /*
    while(*ptr!='\0')
    {
        printf("%llu ",*ptr);
        ptr++;
    }
    printf("\n");
    */

    tmp2 = CsM_MaxUll(&numbers[0],sizeof(numbers)/sizeof(ull));
    printf("main: Max = %llu\n",tmp2);
    tmp2 = CsM_LeastCommonMultiple(&numbers[0],20);
    printf("Least Common Multiple = %llu", tmp2);

    //free(tmp.factor);
    //free(tmp.power);
    //free(ptr);

    return 0;
}

ull* CsM_PrimesUntilUll(ull number)
{
    ull tmp;
    ull i;
    ull j;
    ull* ptr = NULL;

    if(number>1)
    {
        if(number<3)
        {
            ptr = (ull *)realloc(ptr, 2*sizeof(ull));
            ptr[0] = 2;
            ptr[1] = 0;
        }
        else
        {
            ptr = (ull *)realloc(ptr, 3*sizeof(ull));
            ptr[0] = 2;
            ptr[1] = 3;

            i = 2;
            j = 0;
            tmp = ptr[1] + 2;
            while(tmp<=number)
            {
                while(j<i)
                {
                    if(tmp%ptr[j]==0)
                    {
                        j = 0;
                        tmp += 2;
                        break;
                    }
                    else
                    {
                        j++;
                    }
                }
                if(j==i)
                {
                    ptr = (ull *)realloc(ptr, (i+1)*sizeof(ull));
                    ptr[i++] = tmp;
                    //i++;
                    j = 0;
                    tmp += 2;
                }
            }

            ptr =  (ull *)realloc(ptr, (i+1)*sizeof(ull));
            ptr[i] = '\0';

            printf("CsM_PrimesUntilUll:\n");
            i = 0;
            while(ptr[i]!='\0')
            {
                printf("%llu ",ptr[i]);
                i++;
            }
            printf("\n");
        }
    }

    return ptr;
}

struct CsM_PrimeFactorsUll CsM_PrimeFactorisationUll(ull number, ull* primes, ull meret)
{
    struct CsM_PrimeFactorsUll res;
    res.meret  = 0;
    res.factor = NULL;
    res.power  = NULL;
    ull i = 0;
    ull j = 0;
    ull tmp = 0;
    ull tmpnumber = number;

    //printf("Size: %llu\n",res.meret);

    if(primes==NULL)//No auxiliary primes. First factorisation must be done.
    {
        if(tmpnumber>1)
        {
            if(tmpnumber<3)
            {
                res.meret     = 1;
                res.factor[0] = 2;
                res.power[0]  = 1;
            }
            else
            {
                res.factor = (ull *)realloc(res.factor, 2*sizeof(ull));
                res.power  = (int *)realloc(res.power, 2*sizeof(int));
                res.meret  = 2;
                res.factor[0] = 2;
                res.factor[1] = 3;
                res.power[0]  = 0;
                res.power[1]  = 0;

                i = 0;
                while(tmpnumber>1)
                {
                    while(i<res.meret)
                    {
                        //Testing variable "tmpnumber" for the available primes.
                        //printf("Size: %llu\n",res.meret);
                        res.power[i] = 0;//Set power to default.
                        while(tmpnumber%res.factor[i]==0)
                        {
                            //If "tmpnumber" is divisible, power is alculated.
                            tmpnumber /= res.factor[i];//Avoiding testing for all primes until "number".
                            res.power[i]++;
                        }
                        //printf("%llu^%d\n",res.factor[i],res.power[i]);
                        i++;
                    }

                    if(tmpnumber!=1)//If factorisation not finished, find a new prime!
                    {
                        res.meret++;//Need for new prime. Memory allocated for factor candidate.
                        res.factor = (ull *)realloc(res.factor, res.meret*sizeof(ull));
                        res.power  = (int *)realloc(res.power, res.meret*sizeof(int));

                        j = 0;
                        tmp = res.factor[res.meret-2] + 2;//Candidate for prime.
                        while(j<i)
                        {
                            //Testing odd number "tmp" for being a prime.
                            if(tmp%res.factor[j]==0)
                            {
                                //"tmp" is divisible by a prime, therefore rejected.
                                j = 0;
                                tmp += 2;//New prime candidate.
                                break;
                            }
                            else
                            {
                                j++;//Stepping to next prime to test candidate.
                            }
                        }
                        if(j==i)//Candidate is a prime.
                        {
                            res.factor[i] = tmp;
                        }
                        continue;
                    }
                }
            }
        }
    }
    else //Auxiliary primes available. Factorisation on their base.
    {
        //Setting the result "res" to default.
        res.meret  = meret;
        res.factor = (ull*)calloc(res.meret,sizeof(ull));
        for(i=0; i<meret; i++) res.factor[i] = primes[i];
        res.power  = (int*)calloc(res.meret,sizeof(int));
        for(i=0; i<res.meret; i++) res.power[i] = 0;//Set power to default.

        //Factorising "number" (a.k.a. "tmpnumber") via auxiliary primes.
        for(i=0; i<res.meret; i++)
        {
            //Testing variable "tmpnumber" for the available primes.
            //printf("Size: %llu\n",res.meret);
            while(tmpnumber%res.factor[i]==0)
            {
                //If "tmpnumber" is divisible, power is calculated.
                tmpnumber /= res.factor[i];//Avoiding testing for all primes until "number".
                res.power[i]++;
            }
            if(tmpnumber==0) break; //If factorising result in 1, no further prime checking needed.
            //printf("%llu^%d\n",res.factor[i],res.power[i]);
        }
    }

    /*
    //Output testing the function:
    printf("CsM_PrimeFactorisationUll:\n");
    printf("number = %llu\n",number);
    printf("Size: %llu\n",res.meret);
    i = 0;
    printf("Number = %llu^%d",res.factor[i],res.power[i]);
    i++;
    while(i<res.meret)
    {
        printf(" * %llu^%d",res.factor[i],res.power[i]);
        i++;
    }
    printf("\n\n");
    */
    return res;
}

ull CsM_MaxUll(ull* ptr, ull meret)
{
    ull result = *ptr;
    ull i = 1;
    while(i<meret)
    {
        if(result<*(++ptr)) result = *ptr;
        //printf("result = %llu\n",result);
        i++;
    }
    //printf("CsM_MaxUll: result = %llu\n",result);

    return result;
}

ull CsM_LeastCommonMultiple(ull* numbers, ull meret)
{
    ull max = 0;
    ull lcm = 1;
    ull product = 0;
    ull i = 0, j = 0;
    ull* ptr = NULL;
    struct CsM_PrimeFactorsUll aux, tmp, res;
    aux.meret= 0;
    aux.factor = NULL;
    aux.power = NULL;

    max = CsM_MaxUll(numbers, meret);//Maximum value of the numbers.
    ptr = CsM_PrimesUntilUll(max);//Primes below or equal to the maximum value.

    //Setting the default values for the auxiliary.
    while(ptr[aux.meret]!='\0') aux.meret++;
    //printf("aux.meret = %llu\n",aux.meret);
    aux.factor = (ull*)calloc(aux.meret,sizeof(ull));
    aux.power  = (int*)calloc(aux.meret,sizeof(int));
    for(i=0; i<aux.meret; i++) aux.factor[i] = ptr[i];
    for(i=0; i<aux.meret; i++) aux.power[i] = 0;

    //Setting the default values for the result structure.
    res.meret  = aux.meret;
    res.factor = aux.factor;
    res.power  = (int*)calloc(res.meret,sizeof(int));
    for(j=0; i<res.meret; j++) res.power[j]=0;

    //Searching the smallest powers for each prime factor.
    for(i=0; i<meret; i++)
    {
        tmp = CsM_PrimeFactorisationUll(numbers[i], &(aux.factor[0]), aux.meret);
        for(j=0; j<res.meret; j++)
        {
            if(tmp.power[j]>res.power[j]) res.power[j]=tmp.power[j];
        }
    }

    //Calculation of the least common multiplier.
    for(i=0; i<res.meret; i++)
    {
        product = 1;
        if(res.power[i]>0)
        {
            for(j=0;j<res.power[i];j++) product *= res.factor[i];
        }
        lcm *= product;
    }

    free(tmp.factor);
    free(tmp.power);

    return lcm;
}

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{

    unsigned long long number = 600851475143;
    //unsigned long long number = 117;
    unsigned long long limit, tmp = 0, tmp2 = 0, res = 1;
    unsigned long long *ptr = NULL;
    int i, j;

    ptr = (unsigned long long *)malloc(3*sizeof(unsigned long long));
    ptr[0] = 2;
    ptr[1] = 3;
    ptr[2]='\0';
    i = 0;

    tmp = number;
    tmp2 = number;

    for(j=0; j<2; j++)
    {
        printf("\n");
        printf("tmp: %llu\n",tmp);
        printf("for\n");
        printf("ptr[%d]: %llu\n",j,ptr[j]);
        res = tmp%ptr[j];
        printf("res: %llu\n",res);
        if(res == 0)
        {
            while(tmp2%ptr[j]==0)
                tmp2 /= ptr[j];
            printf("tmp2: %llu\n",tmp2);
            limit = (unsigned long long)sqrt((double)tmp2);
        }
    }
    res = 1;

    i = 2;
    tmp = ptr[i-1] + 2;
    while(tmp <= limit)
    {
        printf("\n");
        printf("Try: %llu\n",tmp);
        for(j=0; j<i; j++)
        {
            //printf("ptr[%d]: %llu\n",j,ptr[j]);
            res = tmp%ptr[j];
            //printf("res: %llu\n",res);
            if(res == 0)
            {
                break;
            }
        }
        if(res)
        {
            ptr = (unsigned long long *) realloc(ptr, (i+2)*sizeof (unsigned long long));
            ptr[i+1] = '\0';
            ptr[i] = tmp;
            printf("New prime[%d]: %llu\n",i,ptr[i]);
            printf("Size of ptr: %d\n",sizeof(ptr)/sizeof(unsigned long long));
            if(tmp2%ptr[i]==0)
            {
                printf("Prime factor: %llu\n",ptr[i]);
                while(tmp2%ptr[j]==0)
                    tmp2 /= ptr[j];
                printf("New tmp2: %llu\n",tmp2);
                limit = (unsigned long long)sqrt((double)tmp2);
            }
            i++;
            printf("i = %d\n",i);
        }
        tmp += 2;
        res = 1;
    }
    if(tmp2>1)
    {
        printf("tmp: %llu\n",tmp2);
        ptr = (unsigned long long *) realloc(ptr, (i+2)*sizeof (unsigned long long));
        printf("Size of ptr: %d\n",sizeof(ptr)/sizeof(unsigned long long));
        ptr[i+1] = '\0';
        ptr[i] = tmp2;
    }

    i = 0;
    printf("\n");
    printf("Result:\n");
    printf("The prime factors are:\n");
    while(*ptr)
    {
        printf("prime[%d]: %llu\n",i,*ptr);
        i++;
        ptr++;
    }

    free(ptr);
    return 0;
}

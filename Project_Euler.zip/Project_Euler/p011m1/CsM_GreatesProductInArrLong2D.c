#define __USE_MINGW_ANSI_STDIO 1
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

long long CsM_GreatestProductInArrLong2D(long** arr, long row, long col, long length)
{
    long long result=0;//Final result.
    long long tmp=1;//Temporary result.
    long i = 0,j = 0,k = 0;//Running indexes.

    //Horizontal product
    for(i=0; i<row; i++)
    {
        for(j=0; j<=col-length; j++)
        {
            tmp = 1;
            for(k=0; k<length; k++) tmp*=arr[i][j+k];
            if(tmp > result) result = tmp;
            //printf("tmp = %lld\n",tmp);
        }
    }

    //Vertical product
    for(i=0; i<=row-length; i++)
    {
        for(j=0; j<=col; j++)
        {
            tmp = 1;
            for(k=0; k<length; k++) tmp*=arr[i+k][j];
            if(tmp > result) result = tmp;
            //printf("tmp = %lld\n",tmp);
        }
    }

    //Diagonal product down-right
    for(i=0; i<=row-length; i++)
    {
        for(j=0; j<=col-length; j++)
        {
            tmp = 1;
            for(k=0; k<length; k++) tmp*=arr[i+k][j+k];
            if(tmp > result) result = tmp;
            //printf("tmp = %lld\n",tmp);
        }
    }

    //Diagonal product down-left
    for(i=0; i<=row-length; i++)
    {
        for(j=col-1; j>length-1; j--)
        {
            tmp = 1;
            for(k=0; k<length; k++) tmp*=arr[i+k][j-k];
            if(tmp > result) result = tmp;
            //printf("tmp = %lld\n",tmp);
        }
    }

    return result;
}

/*
Coin sums
Problem 31

In the United Kingdom the currency is made up of pound (�) and pence (p). There are eight coins in general circulation:

    1p, 2p, 5p, 10p, 20p, 50p, �1 (100p), and �2 (200p).

It is possible to make �2 in the following way:

    1ף1 + 1�50p + 2�20p + 1�5p + 1�2p + 3�1p

How many different ways can �2 be made using any number of coins?
*/
#include <stdio.h>
#include <stdlib.h>

int main()
{
    //Variables
    int poundvalue[7] = {100, 50, 20, 10, 5, 2, 1};
    int limit[7] = {1, 4, 10, 20, 40, 100, 198};
    int index[7];
    //int indexlimit[7];
    //int i;
    //int indextmp;
    int k = 0;
    int sum = 0;
    int sumtmp = 0;
    int sumarr[7];
    long differentways = 3;//200p*1, 100p*2. 1p*200

    //Calculation
    sum = 0;
    //100p
    for(index[0]=0; index[0]<=limit[0]; index[0]++)
    {
        for(k=0; k<7; k++) sumarr[k]=0;
        sum = 0;
        sumtmp = index[0]*poundvalue[0];
        sum += sumtmp;
        sumarr[0] = sumtmp;
        //50p
        for(index[1]=0; index[1]<=limit[1]; index[1]++)
        {
            sumtmp = index[1]*poundvalue[1];
            //if(sum + sumtmp>200) break;
            sum += sumtmp;
            sumarr[1] = sumarr[0]+sumtmp;
            if(sumarr[1]>200) break;
            //20p
            for(index[2]=0; index[2]<=limit[2]; index[2]++)
            {
                sumtmp = index[2]*poundvalue[2];
                //if(sum + sumtmp>200) break;
                sum += sumtmp;
                sumarr[2] = sumarr[1]+sumtmp;
                if(sumarr[2]>200) break;
                //10p
                for(index[3]=0; index[3]<=limit[3]; index[3]++)
                {
                    sumtmp = index[3]*poundvalue[3];
                    //if(sum + sumtmp>200) break;
                    sum += sumtmp;
                    sumarr[3] = sumarr[2]+sumtmp;
                    if(sumarr[3]>200) break;
                    //5p
                    for(index[4]=0; index[4]<=limit[4]; index[4]++)
                    {
                        sumtmp = index[4]*poundvalue[4];
                        //if(sum + sumtmp>200) break;
                        sum += sumtmp;
                        sumarr[4] = sumarr[3]+sumtmp;
                        if(sumarr[4]>200) break;
                        //2p
                        for(index[5]=0; index[5]<=limit[5]; index[5]++)
                        {
                            sumtmp = index[5]*poundvalue[5];
                            //if(sum + sumtmp>200) break;
                            sum += sumtmp;
                            sumarr[5] = sumarr[4]+sumtmp;
                            if(sumarr[5]>200) break;
                            //1p
                            for(index[6]=0; index[6]<=limit[6]; index[6]++)
                            {
                                sumtmp = index[6]*poundvalue[6];
                                //if(sum + sumtmp>200) break;
                                sum += sumtmp;
                                sumarr[6] = sumarr[5]+sumtmp;
                                if(sumarr[6]>200) break;
                                //sum = 0;
                                //for(k=0;k<7;k++) sum += poundvalue[k]*index[k];
                                printf("sum = %d\n", sumarr[6]);
                                if(sumarr[6]==200)
                                {
                                    differentways++;
                                    printf("sum = %d, differentways = %ld\n", sumarr[6], differentways);
                                }
                                else
                                {
                                    printf("sum = %d\n", sumarr[6]);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    //Printing results
    printf("differentways = %ld\n", differentways);
    return 0;
}

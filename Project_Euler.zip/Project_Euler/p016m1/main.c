/*
Power digit sum
Problem 16

2^15 = 32768 and the sum of its digits is 3 + 2 + 7 + 6 + 8 = 26.

What is the sum of the digits of the number 2^1000?
*/

#define __USE_MINGW_ANSI_STDIO 1
#include <stdio.h>
#include <stdlib.h>

int main()
{
    //Variables
    char *p[3];
    char carry = 0, tmp = 0;
    int size[3];
    int i,j,k,power,result = 0;

    p[0] = (char*)calloc(1, sizeof(char));
    p[1] = (char*)calloc(1, sizeof(char));
    p[2] = (char*)calloc(1, sizeof(char));
    size[0] = 1;
    size[1] = 1;
    size[2] = 1;
    p[0][0] = 2;
    p[1][0] = 2;
    p[2][0] = 0;

    printf("2 to the power of [int]: ");
    scanf("%d",&power);

    for(i = 1; i<power; i++)
    {
        //Printing new cycle inputs and former cycle output.
        printf("\ni = %d:\n",i);
        /*printf("Input:\n");
        for(j=0; j<3; j++)
        {
            printf(" *p[%d] = ",j);
            for(k=size[j]-1; k>=0; k--) printf("%d",(int)p[j][k]);
            printf("\n");
        }*/

        //Resetting carry.
        carry = 0;

        //Power calculation cycle
        for(k=0; k<size[2]; k++) p[2][k] = 0;
        for(k=0; k<size[2]; k++)
        {
            //printf(" k = %d\n",k);
            tmp = p[0][k]*2+carry;
            //printf("  tmp = %d\n",tmp);
            p[2][k] = tmp%10;
            carry = tmp/10;
            if(p[2][k] < 0) printf("  p[2][%d] < 0 : (p[0][%d]*2 + carry)%c10 = (%d*2 + %d)%c10 = %d\n", k, k,'%', (int)p[0][k], (int)carry, '%', (int)p[2][k]);
            if(carry < 0) printf("  carry < 0 : (p[0][%d]*2+carry)/10 = (%d*2+%d)/10 = %d\n", k, p[0][k], carry, tmp/10);
            if(k==(size[2]-1) && carry>0)
            {
                //printf(" size[2]=%d\n", size[2]);
                //printf(" k = %d\n", k);
                //printf(" p[2][%d] = %d\n", size[2]-1, p[2][k]);
                //printf(" carry = %d\n", carry);
                size[2] += 1;
                //printf(" 1 increment.\n");
                //printf(" size[2] = %d\n", size[2]);
                p[2] = (char*)realloc(p[2], (size[2])*sizeof(char));
                p[2][size[2]-1] = carry;
                //printf(" p[2][size[2]-1]=p[2][%d] = %d\n", size[2]-1, p[2][size[2]-1]);
                //goto knoincr;
                break;//Goto is not necessary.
            }
        }
        //knoincr:;

        //Printing cycle results.
        printf("Cycle result:\n");
        /*for(j=0; j<3; j++)
        {
            printf(" *p[%d] = ",j);
            for(k=size[j]-1; k>=0; k--) printf("%d",(int)p[j][k]);
            printf("\n");
        }*/
        //printf(" size[2]=%d\n", size[2]);
        printf(" 2^%d = ", i+1);
        for(k = size[2]-1; k>=0; k--) printf("%d", (int)p[2][k]);
        printf("\n");

        //Allocating memory to next input, if necessary.
        if(size[0]<size[2])
        {
            size[0]= size[2];
            p[0] = (char*)realloc(p[0], size[0]*sizeof(char));
        }

        //Copying present cycle output into next input.
        //for(k=0; k<size[0]; k++) p[0][k] = 0;
        for(k=0; k<size[0]; k++) p[0][k] = p[2][k];
    }

    //Printing end results
    printf("\nPower calculation end results:\n");
    printf(" size[2] = %d\n", size[2]);
    printf(" 2^%d = ", power);
    for(k = size[2]-1; k>=0; k--) printf("%d", (int)p[2][k]);
    printf("\n");
    //Sum of digits
    for(k = 0; k < size[2]; k++) result += (int)p[2][k];
    printf("Sum of digits = %d\n", result);

    //Freeing memory
    for(j=0; j<3; j++) free(p[j]);

    return 0;
}

#ifndef CSM_MATH_H_INCLUDED
#define CSM_MATH_H_INCLUDED

#define ull unsigned long long

struct CsM_DinArrInt1D
{
    long long meret;
    int* numbers;
};
struct CsM_DinArrIntND
{
    long dimensions;
    long long *meret;
    int* numbers;
};

struct CsM_PrimeFactorsUll
{
    unsigned long long  meret;
    unsigned long long* factor;
    int* power;
};

struct CsM_SequenceUll
{
    ull* sequence;
    ull meret;
};

ull FactorialInt(int);
long long CsM_GreatestProductInLineInt(int *, ull, ull);
ull CsM_LeastCommonMultiple(ull*, ull);
struct CsM_DinArrInt1D CsM_LexicographicPermutation(int, ull);
ull CsM_MaxUll(ull*, ull);
struct CsM_PrimeFactorsUll CsM_PrimeFactorisationUll(ull, ull*, ull);
ull* CsM_PrimesUntilUll(ull);
//void CsM_PrimesUntilUll(ull*, ull);
struct CsM_SequenceUll CsM_CollatzUll(ull);

#endif // CSM_MATH_H_INCLUDED

#include <stdlib.h>
#include "CsM_Math.h"
#define ull unsigned long long

ull* CsM_PrimesUntilUll(ull number)
//void CsM_PrimesUntilUll(ull* ptr, ull number)
{
    ull tmp;
    ull i;
    ull j;
    ull* ptr = 0;

    ptr = (ull *)realloc(ptr, 3*sizeof(ull));
    ptr[0] = 2;
    ptr[1] = 3;

    i = 2;
    j = 0;
    tmp = ptr[1] + 2;
    while(tmp<=number)
    {
        while(j<i)
        {
            if(tmp%ptr[j]==0)
            {
                j = 0;
                tmp += 2;
                break;
            }
            else
            {
                j++;
            }
        }
        if(j==i)
        {
            ptr = (ull *)realloc(ptr, (i+1)*sizeof(ull));
            ptr[i++] = tmp;
            //i++;
            j = 0;
            tmp += 2;
        }
    }

    ptr =  (ull *)realloc(ptr, (i+1)*sizeof(ull));
    ptr[i] = '\0';

    return ptr;
}

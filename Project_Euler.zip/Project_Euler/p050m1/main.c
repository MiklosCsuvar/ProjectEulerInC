/*
Consecutive prime sum
Problem 50

The prime 41, can be written as the sum of six consecutive primes:
41 = 2 + 3 + 5 + 7 + 11 + 13
This is the longest sum of consecutive primes that adds to a prime below one-hundred.
The longest sum of consecutive primes below one-thousand that adds to a prime, contains 21 terms, and is equal to 953.
Which prime, below one-million, can be written as the sum of the most consecutive primes?
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "CsM_Math.h"

int main()
{
    ull *primes = NULL;
    ull limit = 999999;
    long count;
    ull maxprime;
    ull resultprime;
    long tmpsum;
    long limit2;
    long i;
    long j;
    long tmplength;
    long resultlength;

    primes = CsM_PrimesUntilUll(limit);
    printf("Base primes found.\n");

    count = 0;
    while(primes[count++]!=0);
    tmpsum = 0;
    for(tmpsum=0;tmpsum<count;tmpsum++) printf("%llu ",primes[tmpsum]);
    printf("\n");
    maxprime = primes[count-2];
    printf("count = %ld, maxprime = %llu\n",count, maxprime);

    tmpsum = primes[0]+primes[1];
    tmplength = 2;
    resultlength = 2;
    limit2 = tmplength;
    while(tmpsum<=maxprime)
    {
        j = limit2;
        while(primes[j]<=tmpsum)
        {
            if(tmpsum==primes[j])
            {
                if(tmplength>resultlength)
                {
                    resultlength = tmplength;
                    resultprime = primes[j];
                    limit2 = j;
                    printf("2: resultprime = %llu, resultlength = %ld, tmpsum = %ld\n",resultprime, resultlength, tmpsum);
                }
                break;
            }
            j++;
        }
        tmpsum += (primes[tmplength]+primes[tmplength+1]);
        tmplength += 2;
    }

    for(i=1;i<count-2;i++)
    {
        tmplength = resultlength;
        if(resultlength%2==0) tmplength = resultlength+1;
        tmpsum=0;
        for(j=i;j<i+tmplength;j++) tmpsum += primes[j];
        limit2 = j+1;
        while(tmpsum<=maxprime)
        {
            printf("3: i = %ld, tmplength = %ld\n",i, tmplength);
            j = limit2;
            while(primes[j]<=tmpsum)
            {
                if(primes[j]==tmpsum)
                {
                    if(tmplength>resultlength)
                    {
                        resultlength = tmplength;
                        resultprime = primes[j];
                        limit2 = j;
                        printf("3: resultprime = %llu, resultlength = %ld, tmpsum = %ld\n",resultprime, resultlength, tmpsum);
                    }
                    break;
                }
                j++;
            }
            tmplength += 2;
            tmpsum += (primes[i+tmplength-2]+primes[i+tmplength-1]);
        }
    }

    printf("\nFinal: resultprime = %llu, resultlength = %ld, tmpsum = %ld\n",resultprime, resultlength, tmpsum);

    free(primes);
    return 0;
}


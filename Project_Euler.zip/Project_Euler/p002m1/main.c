#include <stdio.h>
#include <stdlib.h>

int main()
{
    long long fibonacci[3] = {1,1,0};
    long long i = 2;
    long long tmp_fib = 0;
    long long sum = 0;

    fibonacci[i%3] = fibonacci[(i-1)%3]+fibonacci[(i-2)%3];
    tmp_fib = fibonacci[i%3];
    while (tmp_fib <= 4000000)
    {
        if(tmp_fib%2 == 0)
        {
            sum += tmp_fib;
        }
        ++i;
        printf("i: %lld\n",i);
        fibonacci[i%3] = fibonacci[(i-1)%3]+fibonacci[(i-2)%3];
        tmp_fib = fibonacci[i%3];
        printf("tmp_fib = %lld\n",tmp_fib);
    }

    printf("Result: %lld\n",sum);
    return 0;
}

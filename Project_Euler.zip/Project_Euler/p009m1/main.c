/*
TasK:
A Pythagorean triplet is a set of three natural numbers, a < b < c, for which,
a^2 + b^2 = c^2
For example, 32 + 42 = 9 + 16 = 25 = 52.
There exists exactly one Pythagorean triplet for which a + b + c = 1000.
Find the product abc.
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int a=0, b=0, c=0, i=0, j=0, start_i=0, idx = 0;

    start_i = (int)(1000*(1/(1+sqrt(2))));

    for (i=start_i; i<1000; i++)
    {
        for(j=i+2; j<(i+1002)/2; j++)
        {
            c = i-1;
            b = j-i-1;
            a = 1000-c-b;

            if(a+b<=c)
                break;

            if(a*a+b*b==c*c)
            {
                ++idx;
                printf("%dth Pythagorean triplet: %d, %d, %d.\n",idx, a,b,c);
                printf("Their product: abc = %ld.\n",a*b*c);
            }
        }
    }

    return 0;
}

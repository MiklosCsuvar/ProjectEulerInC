#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "CsM_math.h"

struct CsM_DynArrLld2DGeneral* CsM_FileToDynArrLld2DGeneral(FILE *f)
{
    //Variables
    struct CsM_DynArrLld2DGeneral a = {0,NULL,NULL};
    struct CsM_DynArrLld2DGeneral *r;
    long long i = 0, j = 0, k = 0;
    long long tmp = 0;
    char s[10];
    char s2[2] = {'\0','\0'};
    char c;

    //Printing input file
    printf("Function CsM_FileToDynArrLld2DGeneral start.\n");
    printf("Printing input file:\n");
    fseek(f, 0, SEEK_SET);
    while((c = getc(f)) != EOF) putc(c, stdout);
    printf("\n");

    //Calculating triangle parameter
    a.numberoflines = 0;
    fseek(f, 0, SEEK_SET);
    while((c = getc(f)) != EOF) if(c == '\n') a.numberoflines++;
    a.numberoflines++;
    printf("\nnumberoflines = %lld\n",a.numberoflines);

    //Memory allocation
    a.number = (long long**)calloc(a.numberoflines, sizeof(long*));
    a.sizeoflines = (long long*)calloc(a.numberoflines, sizeof(long long));

    //
    fseek(f, 0, SEEK_SET);
    i = 0;
    tmp = 0;
    c = getc(f);
    while(c != EOF)
    {
        while(c != EOF && c != '\n')
        {
            if(c == ' ') tmp++;
            c = getc(f);
        }
        tmp++;
        a.sizeoflines[i] = tmp;
        //printf("Line %d\n", __LINE__);
        a.number[i] = (long long*)calloc(a.sizeoflines[i], sizeof(long long));
        i++;
        tmp = 0;
        c = getc(f);
    }

    //Reading input into array
    fseek(f, 0, SEEK_SET);
    i = 0;
    j = 0;
    tmp = 0;
    c = getc(f);

    //Reading file.
    while(c != EOF)
    {
        //printf("Line %d - Running while(c != EOF)\n", __LINE__);
        //Reading line.
        while(!isdigit(c)) c = getc(f);
        while(c != '\n')
        {
            //printf("Line %d - Running while(c != per n)\n", __LINE__);
            while(!isdigit(c)) c = getc(f);
            //Reading a number in line.
            while(isdigit(c))
            {
                //putc(c, stdout);
                s2[0] = c;
                strcat(s,s2);
                c = getc(f);
            }
            a.number[i][j] = atoi(s);
            for(k=0; k<10; k++) s[k] = '\0';
            j++;
            if(c == '\n')
            {
                i++;
                j = 0;
            }
            else if(c == EOF)
            {
                break;
            }
            else
            {
                while(!isdigit(c)) c = getc(f);
            }
            //printf("Line %d - End of  while(c != EOF && c !=  per n)\n", __LINE__);
            //printf("c = %c\n",c);
        }
    }
    //printf("Line %d - End of while(c != EOF)\n", __LINE__);

    printf("\nPrinting results:\n");
    printf("numberoflines = %lld\n",a.numberoflines);
    for(i=0; i<a.numberoflines; i++) printf("sizeoflines[%2.d] = %lld\n", i, a.sizeoflines[i]);
    printf("\ninput array:\n");
    for(i=0; i<a.numberoflines; i++)
    {
        for(j=0; j<a.sizeoflines[i]; j++)
        {
            printf("%2.lld ",a.number[i][j]);
        }
        printf("\n");
    }
    r = &a;

    printf("Function CsM_FileToDynArrLld2DGeneral end.\n");

    //return a;
    return r;
}

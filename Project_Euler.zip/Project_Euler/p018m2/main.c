/*
Maximum path sum I
Problem 18

By starting at the top of the triangle below and moving to adjacent numbers on the row below, the maximum total from top to bottom is 23.

3
7 4
2 4 6
8 5 9 3

That is, 3 + 7 + 4 + 9 = 23.

Find the maximum total from top to bottom of the triangle below:

75
95 64
17 47 82
18 35 87 10
20 04 82 47 65
19 01 23 75 03 34
88 02 77 73 07 63 67
99 65 04 28 06 16 70 92
41 41 26 56 83 40 80 70 33
41 48 72 33 47 32 37 16 94 29
53 71 44 65 25 43 91 52 97 51 14
70 11 33 28 77 73 17 78 39 68 17 57
91 71 52 38 17 14 91 43 58 50 27 29 48
63 66 04 68 89 53 67 30 73 16 69 87 40 31
04 62 98 27 23 09 70 98 73 93 38 53 60 04 23

NOTE: As there are only 16384 routes, it is possible to solve this problem by trying every route. However, Problem 67, is the same challenge with a triangle containing one-hundred rows; it cannot be solved by brute force, and requires a clever method! ;o)
*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "CsM_math.h"

int main()
{
    //Variables
    FILE *f = fopen("p018_numbers.txt","r");
    struct CsM_DynArrLld2DGeneral t = {0,NULL,NULL};
    struct CsM_DynArrLld2DGeneral *p;// = &triangle;
    long long tmp = 0;
    int idx[2] = {0,0};
    long long i = 0, j = 0, k = 0;
    char **direction = NULL;
    long long *sum = NULL;

    t = *(CsM_FileToDynArrLld2DGeneral(f));
    printf("Line %d - Got pointer\n", __LINE__);
    printf("numberoflines = %lld\n", (long long)t.numberoflines);

    //Memory allocation
    //t = *p;
    sum = (long long*)calloc(t.sizeoflines[t.numberoflines-1], sizeof(long long));
    direction = (char**)calloc(t.numberoflines-1, sizeof(char*));
    //printf("Line %d: Memory allocated\n", __LINE__);
    for(i = 0; i<t.numberoflines-1; i++) direction[i] = (char*)calloc(t.sizeoflines[t.numberoflines-2], sizeof(char));
    //printf("Line %d: Memory allocated\n", __LINE__);
    for(i = 0; i<t.numberoflines; i++) printf("sizeoflines[%lld] = %d\n",i, t.sizeoflines[i]);
    //printf("Line %d: Memory allocated\n", __LINE__);

    //Printing the input triangle.
    printf("\nInput triangle:\n");
    for(i = 0; i<t.numberoflines; i++)
    {
        for(j = 0; j<t.sizeoflines[i]; j++)
        {
            printf("%2.d ",t.number[i][j]);
        }
        printf("\n");
    }
    printf("\n");

    //Processing triangle
    for(j = 0; j<t.sizeoflines[t.numberoflines-1]; j++) sum[j] = t.number[t.numberoflines-1][j];
    printf("Initial values of sum:\n");
    for(j = 0; j<t.sizeoflines[t.numberoflines-1]; j++) printf("%2.d ", sum[j]);
    printf("\n");
    //printf("Line %d\n", __LINE__);

    for(i = t.numberoflines-2; i>=0; i--)
    {
        //printf("Line %d\n", __LINE__);
        for(j=0; j<t.sizeoflines[i]; j++)
        {
            //printf("Line %d\n", __LINE__);
            //printf("i, j = %d, %d, p->sizeoflines[%d] = %d\n", i, j, i, p->sizeoflines[i]);
            if(sum[j]>=sum[j+1])
            {
                direction[i][j] = '0';
                sum[j] = t.number[i][j]+sum[j];
                //printf("Line %d\n", __LINE__);
            }
            else
            {
                direction[i][j] = '1';
                sum[j] = t.number[i][j]+sum[j+1];
                for(k=i+1;k<=t.numberoflines-2;k++) direction[k][j] = direction[k][j+1];
                //printf("Line %d\n", __LINE__);
            }
        }
    }
    //printf("Line %d - Double for end.\n", __LINE__);

    //Printing the results
    printf("\nThe maximum total from top to bottom of the triangle: %d\n\n", sum[0]);
    printf("Direction from top: ");
    for(i=0; i<t.numberoflines-1; i++) printf("%c",direction[i][0]);
    printf("\n\n");
    printf("The numbers in path:\n");
    idx[0] = 0;
    idx[1] = 0;
    printf("triangle[ %d][ %d] = %lld\n", idx[0], idx[1], t.number[idx[0]][idx[1]]);
    tmp = t.number[idx[0]][idx[1]];
    for(i = 0; i<t.numberoflines-1; i++)
    {
        ++idx[0];
        if(direction[i][0] == '1') ++idx[1];
        tmp += t.number[idx[0]][idx[1]];
        printf("triangle[%2.d][%2.d] = %lld\n", idx[0], idx[1], t.number[idx[0]][idx[1]]);
    }
    printf("Total = %lld", tmp);


    //Freeing memory.
    free(sum);
    for(i = 0; i<t.numberoflines-1; i++) free(direction[i]);
    free(direction);
    for(i = 0; i<t.numberoflines; i++) free(t.number[i]);
    free(t.sizeoflines);
    //free(p);

    return 0;
}

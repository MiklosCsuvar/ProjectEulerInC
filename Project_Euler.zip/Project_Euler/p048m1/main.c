#include <stdio.h>
#include <stdlib.h>

int main()
{
    long long tmp = 0, result = 0;
    int i = 0, j = 0;

    for(i = 1; i<=1000; i++)
    {
        printf("i = %d\n",i);
        if(i%10)
        {
            tmp = 1;
            for(j=1; j<=i;j++) tmp = (tmp*i)%10000000000;
            result = (result+tmp)%10000000000;
        }
    }

    printf("Result = %lld\n", result);
    return 0;
}

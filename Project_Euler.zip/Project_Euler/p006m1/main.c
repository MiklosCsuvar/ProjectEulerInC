#include <stdio.h>
#include <stdlib.h>

int main()
{
    unsigned int sumofsqs = 0, sqofsum = 0;
    int i = 0;

    for(i = 1;i<=100;i++)
    {
        sumofsqs += i*i;
        sqofsum  += i;
    }

    printf("Result: %d\n",sqofsum*sqofsum-sumofsqs);
    return 0;
}

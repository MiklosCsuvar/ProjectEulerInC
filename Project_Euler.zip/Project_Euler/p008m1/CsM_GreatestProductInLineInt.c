long long CsM_GreatestProductInLineInt(int *seq, unsigned long long size, unsigned long long member)
{
    long long prod = 0;
    long long tmp = 0;
    unsigned long long i = 0;
    unsigned long long j = 0;

    for(i=0; i<size-member; i++)
    {
        tmp = 1;
        for(j=0; j<member; j++) tmp *= seq[i+j];
        if(tmp>prod) prod = tmp;
    }

    return prod;
}

#ifndef CSM_MATHINT_H_INCLUDED
#define CSM_MATHINT_H_INCLUDED

long long CsM_GreatestProductInLineInt(int *, unsigned long long, unsigned long long);

#endif // CSM_MATHINT_H_INCLUDED

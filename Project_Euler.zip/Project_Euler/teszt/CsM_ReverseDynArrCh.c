#include "CsM_math.h"

struct CsM_ReverseDynArrCh(struct CsM_DynArrCh1D arr)
{
    struct CsM_DynArrCh1D result;
    long long i,limit;

    result.meret = arr.meret;
    result.character = (char*)malloc(result.meret,sizeof(char));

    for(i=0;i<result.meret/2;i++) result.character[i]=arr.character[meret-1-i];

    return result;
}

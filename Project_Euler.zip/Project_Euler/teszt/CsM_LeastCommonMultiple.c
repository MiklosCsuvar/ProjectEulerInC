#include <stdlib.h>
#include "CsM_MathUll.h"

ull CsM_LeastCommonMultiple(ull* numbers, ull meret)
{
    ull max = 0;
    ull lcm = 1;
    ull product = 0;
    ull i = 0, j = 0;
    ull* ptr = NULL;
    struct CsM_PrimeFactorsUll aux, tmp, res;
    aux.meret= 0;
    aux.factor = NULL;
    aux.power = NULL;

    max = CsM_MaxUll(numbers, meret);//Maximum value of the numbers.
    ptr = CsM_PrimesUntilUll(max);//Primes below or equal to the maximum value.

    //Setting the default values for the auxiliary.
    while(ptr[aux.meret]!='\0') aux.meret++;
    //printf("aux.meret = %llu\n",aux.meret);
    aux.factor = (ull*)calloc(aux.meret,sizeof(ull));
    aux.power  = (int*)calloc(aux.meret,sizeof(int));
    for(i=0; i<aux.meret; i++) aux.factor[i] = ptr[i];
    for(i=0; i<aux.meret; i++) aux.power[i] = 0;

    //Setting the default values for the result structure.
    res.meret  = aux.meret;
    res.factor = aux.factor;
    res.power  = (int*)calloc(res.meret,sizeof(int));
    for(j=0; i<res.meret; j++) res.power[j]=0;

    //Searching the smallest powers for each prime factor.
    for(i=0; i<meret; i++)
    {
        tmp = CsM_PrimeFactorisationUll(numbers[i], &(aux.factor[0]), aux.meret);
        for(j=0; j<res.meret; j++)
        {
            if(tmp.power[j]>res.power[j]) res.power[j]=tmp.power[j];
        }
    }

    //Calculation of the least common multiplier.
    for(i=0; i<res.meret; i++)
    {
        product = 1;
        if(res.power[i]>0)
        {
            for(j=0;j<res.power[i];j++) product *= res.factor[i];
        }
        lcm *= product;
    }

    free(tmp.factor);
    free(tmp.power);

    return lcm;
}

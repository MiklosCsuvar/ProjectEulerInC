#include <stdlib.h>

unsigned long long RotatingULL(unsigned long number, int shift)
{
    typedef unsigned long ull;
    ull tmp;
    int numberofdigits = 1;
    int i;
    ull tentopower;

    if(shift==0)
    {
        return number;
    }

    numberofdigits = (int)log10((double)number) + 1;
    printf("numberofdigits: %d\n",numberofdigits);
    i = 1;
    tentopower = 1;
    while(i<numberofdigits)
    {
        tentopower *= 10;
        i++;
    }
    printf("tentopower = %lu\n",tentopower);

    if(shift>0)
    {
        i = 1;
        while(i<=shift)
        {
            tmp = number/tentopower;
            printf("tmp: %lu\n",tmp);
            number = 10*(number%tentopower)+tmp;
            printf("number: %lu\n",number);
            i++;
        }
    }
    else
    {
        i = -1;
        while(i>=shift)
        {
            tmp = number%10;
            printf("tmp: %lu\n",tmp);
            number = (number-tmp)/10 + tmp*tentopower;
            printf("number: %lu\n",number);
            i--;
        }
    }

    return number;
}

#endif // ROTATINGULL_H_INCLUDED

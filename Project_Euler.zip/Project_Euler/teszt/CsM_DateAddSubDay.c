#include "CsM_calendar.h"

struct date CsM_DateAddSubDay(struct date, long day)
{
    //Variables
    struct date result;
    short daysinmonth;

    //Calculation
    daysinmonth = CsM_DaysInMonth(date.year, date.month);



    return result;
}

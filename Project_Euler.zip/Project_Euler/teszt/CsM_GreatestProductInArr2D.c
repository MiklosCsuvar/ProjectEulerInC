#include <stdlib.h>
#include <math.h>

long long CsM_GreatestProductInArrLong2D(long** arr, long* row, long* col, long length)
{
    long long result=0;
    long long tmp=1;
    long i = 0,j = 0,k = 0;
    char truth[2] = {0,0};

    for(i=0; i<*row; i++)
    {
        for(j=0; j<*col; j++)
        {
            truth[0] = (i+length<=row);
            truth[1] = (i+length<=col);

            if(truth[0])
            {
                tmp = 1;
                for(k=0; k<length; k++) tmp *=arr[i+k][j];
                if(tmp>result) result=tmp;
            }

            if(truth[1])
            {
                tmp = 1;
                for(k=0; k<length; k++) tmp *=arr[i][j+k];
                if(tmp>result) result=tmp;
            }

            if(truth[0] && truth[1])
            {
                tmp = 1;
                for(k=0; k<length; k++) tmp *=arr[i+k][j+k];
                if(tmp>result) result=tmp;
            }
        }
    }
    return result;
}

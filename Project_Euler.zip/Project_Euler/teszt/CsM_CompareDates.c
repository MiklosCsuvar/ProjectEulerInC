#include "CsM_date.h"

int CsM_CompareDates(struct date date1, struct date date2)
{
    int result;
    if(date1.year > date2.year)
    {
        result = 1;
    }
    else if(date1.year < date2.year)
    {
        result = -1;
    }
    else
    {
        if(date1.month > date2.month)
        {
            result = 1;
        }
        else if(date1.month < date2.month)
        {
            result = -1;
        }
        else
        {
            if(date1.day > date2.day)
            {
                result = 1;
            }
            else if(date1.day < date2.day)
            {
                result = -1;
            }
            else
            {
                result = 0;
            }
        }
    }
    return result;
}

#include "CsM_math.h"

struct CsM_DynArrCh1D CsM_RevProdOfRevChArr(struct CsM_DynArrCh1D mr, struct CsM_DynArrCh1D md)
{
    struct CsM_DynArrCh1D result;
    char tmp,carry;
    long long i,j;

    result.meret = mr.meret+md.meret;
    result.character = (char*)malloc(result.meret,sizeof(char));

    for(i=0;i<md.meret;i++)
    {
        for(j=0;j<md.meret;j++)
        {
            tmp=mr.character[i]*md.character[j];
            result.character[i+j]=tmp%10;
            carry=(tmp-result.character[i+j])/10;
            result.character[i+j+1]+=carry;
        }
    }

    return result;
}

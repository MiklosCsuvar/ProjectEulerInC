/*
Distances in a Bee's Honeycomb
Problem 354

Consider a honey bee's honeycomb where each cell is a perfect regular hexagon with side length 1.

One particular cell is occupied by the queen bee.
For a positive real number L, let B(L) count the cells with distance from the queen bee cell (all distances are measured from centre to centre);
you may assume that the honeycomb is large enough to accommodate for any distance we wish to consider.
For example, B(squareroot(3)) = 6, B(squareroot(21)) = 12 and B(111111111) = 54.

Find the number of L<=5x10^11 such that B(L) = 450.
*/

#include <stdio.h>
#include <stdlib.h>
#include "CsM_math.h"

int main()
{
    //Variables
    long long lengthsquared = 0; //Actual Length squared.
    long long lengthupplim = 6000000; //Upper limit of Ls: <= 5E11
    long long lengthtocount = 0;
    long long lengthtocountsquared = 0;
    long long column = 0;
    long long columnupperlim = 0;
    long long count = 0;
    long long countlengthwithnbees = 0; //Count of Ls, such B(L) = 450.
    long long k = 0;
    long long numberofbees = 450;
    long long row = 0;

    //Calculation
    k = 2;
    row = k*2;
    column = k;
    lengthtocount = 3*k;
    columnupperlim = column;

    while(lengthtocount <= lengthupplim)
    {
        printf("lengthtocount = %lld\n", lengthtocount);
        lengthtocountsquared = lengthtocount*lengthtocount;
        count = 6;

        while(3*row*row>=lengthtocountsquared) {
            //printf("lengthtocount = %lld, row = %lld\n", lengthtocount, row);
            columnupperlim = columnupperlim<row/2?columnupperlim:row/2;
            lengthsquared = 3*(row*row-row*column+column*column);

            while(lengthsquared<=lengthtocountsquared && column > 0) {
                //printf("lengthtocount = %lld, row = %lld, column = %lld\n", lengthtocount, row, column);
                if(lengthsquared == lengthtocountsquared) {
                    count += 12;
                    if(count>450) {
                        goto lengthtoolarge;
                    }
                    columnupperlim = column;
                    break;
                }
                column--;
            }
            row--;
        }

        if(count == numberofbees) {
            countlengthwithnbees++;
            printf("The count of lengths having %lld bees: %lld.\n", numberofbees, countlengthwithnbees);
        }

        lengthtoolarge:
        k++;
        row = k*2;
        column = k;
        lengthtocount = 3*k;
        columnupperlim = column;
    }

    //Printing result
    printf("Final result: The count of lengths having %lld bees: %lld.\n", numberofbees, countlengthwithnbees);

    //Freeing memory

    return 0;
}

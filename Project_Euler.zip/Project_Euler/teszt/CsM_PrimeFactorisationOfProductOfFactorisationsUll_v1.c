#define __USE_MINGW_STDIO 1
#include <stdlib.h>
#include "CsM_math.h"

void CsM_PrimeFactorisationOfProductOfFactorisationsUll(struct CsM_PrimeFactorsUll *pfac0,struct CsM_PrimeFactorsUll *pfac1,struct CsM_PrimeFactorsUll *pfacres)
{
    ull tmpfactor = 0;
    ull lowerlimit = 0;
    ull upperlimit = 0;
        long long i = 0;
    long long j = 0;
    long long t = 0;
    long long fi[2] = {0,0};//Temporary finding index.
    long long li[2] = {0,0};//Temporary limit index.
    struct CsM_PrimeFactorsUll *fact[3];

    fact[0] = pfac0;
    fact[1] = pfac1;
    fact[2] = pfacres;

    pfacres->number = pfac0->number * pfac1->number;
    while(i < pfac0->meret && j < pfac1->meret)
    {
        t = pfac0->meret-1;
        while(tmpfactor > lowerlimit && t >= 0)
        {
            if(pfac0->factor[t] < tmpfactor)
            {
                tmpfactor = pfac0->factor[t];
                t--;
            }
            t--;
        }
        t = pfac1->meret-1;
        while(tmpfactor > lowerlimit && t >= 0)
        {
            if(pfac1->factor[t] < tmpfactor)
            {
                tmpfactor = pfac1->factor[t];
                t--;
            }
        }
        if(pfacres->meret < 1)
        {
            pfacres->meret = 1;
            pfacres->factor = (ull*)calloc(1, sizeof(ull));
            pfacres->power = (ull*)calloc(1; sizeof(ull));
        }
        else
        {
            pfacres->meret++;
            pfacres->factor = (ull*)realloc(pfacres->meret, sizeof(ull));
            pfacres->factor[pfacres->meret-1] = 0;
            pfacres->power = (ull*)realloc(pfacres->meret, sizeof(ull));
            pfacres->power[pfacres->meret-1] = 0;
        }
        pfacres->factor[pfacres->meret-1] = tmpfactor;
        lowerlimit = tmpfactor;
        j++
    }
    return;
}

#include <string.h>

int CsM_IsPalindromStr(char *str)
{
    int i;
    int length;
    int limit;
    int result;

    length = strlen(str);
    //printf("length = %d\n",length);
    limit = length/2;
    //printf("limit = %d\n",limit);
    result = 1;
    for(i=0;i<limit;i++)
    {
        //printf("i = %d\n",i);
        if(str[i]!=str[length-1-i])
        {
            result = 0;
            break;
        }
    }

    return result;
}

/*
Input:
noe: Number of elements to permutate.
rop: Rank of permutation to calculate. Rank begin at 1.

Output:
result: Structure of
long long: count of indexes,
integer pointer: pointing to indexes of elements relative to their base set.
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "CsM_Math.h"

struct CsM_DynArrInt1D CsM_LexicographicPermutation(int noe, ull rop)
{
    //noe: Number of elements.
    //rop: Rank of permutation.
    struct CsM_DynArrInt1D result;
    int *q = NULL; //Quotient.
    char *o = NULL; //Occupation
    int i = 0; //Cycle index.
    int j = 0; //Auxiliary cycle index.
    unsigned long long rbefore = 0; //Remainder.
    unsigned long long rafter = 0; //Remainder.
    unsigned long long f = 0; //Factorial.
    int tmp = 0; //Auxiliary for loop.

    q = (int *)calloc(noe, sizeof(int));
    o = (char *)calloc(noe, sizeof(char));
    for(i=0; i<noe; i++) o[i] = 0;
    result.meret = noe;
    result.numbers = (int *)calloc(result.meret, sizeof(int));

    rbefore = rop;
    for(i=0; i<noe; i++)
    {
        f = FactorialInt(noe-(i+1));//Calculating factorial to number less than position.
        q[i] = rbefore/f;//These times is the factorial in the rank.
        rafter = rbefore - q[i]*f;//These many permutations remained to fulfill.

        if(rbefore>0 && rafter>0)
        {
            /*Searching for numbers forward, because they must produce
            a low number of their permutations.*/
            j = -1;//Starting point in order to check number at index 0.
            tmp = -1;
            do
            {
                tmp++;//Step to the next index.
                if(o[tmp]==0) j++;//If the number had been used, it is skipped.
            }
            while(j<q[i]);
        }
        else if (rbefore>0 && rafter==0)
        {
            /*Searching for numbers forward the last time.*/
            j = -1;
            tmp = -1;
            do
            {
                tmp++;
                if(o[tmp]==0) j++;
            }
            while(j<q[i]-1);
        }
        else
        {
            /*Searching for numbers backward, because they must produce
            a high number of their permutations.*/
            q[i] = 0;
            tmp = noe-1;
            while(o[tmp]==1) tmp--;
        }
        result.numbers[i] = tmp;
        o[tmp] = 1;//Selected number is marked in order to skip next time.
        rbefore = rafter;//Remainder for the next calculation.
    }
    /*
    //Output testing:
    printf("Quotients:\n");
    for(i=0; i<noe; i++) printf("%d ",q[i]);
    printf("\n");
    */

    return result;
}

#define __USE_MINGW_ANSI_STDIO 1
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "CsM_math.h"

int CsM_IsMadeOfDistinctInt(int number)
{
    int digits[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    int i = 0;
    int digitindex = 0;

    i = 0;
    while(number > 0)
    {
        digits[number%10]++;
        number /= 10;
        i++;
    }

    for(i = 0; i < 10; i++)
    {
        if(digits[i] > 1)
        {
            return 0;
        }
    }
    return 1;
}

#ifndef CSM_STRING_H_INCLUDED
#define CSM_STRING_H_INCLUDED

int CsM_IsPalindromeStr(char *);

#endif // CSM_STRING_H_INCLUDED

#include <stdlib.h>
#include "CsM_Math.h"

ull CsM_MaxUll(ull* ptr, ull meret)
{
    ull result = *ptr;
    ull i = 1;
    while(i<meret)
    {
        if(result<*(++ptr)) result = *ptr;
        //printf("result = %llu\n",result);
        i++;
    }
    //printf("CsM_MaxUll: result = %llu\n",result);

    return result;
}

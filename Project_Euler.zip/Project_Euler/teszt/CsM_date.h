#ifndef CSM_DATE_H_INCLUDED
#define CSM_DATE_H_INCLUDED

struct date
{
    int year;
    char month;
    char day;
};

int CsM_DaysInMonth(int, int);

#endif // CSM_DATE_H_INCLUDED

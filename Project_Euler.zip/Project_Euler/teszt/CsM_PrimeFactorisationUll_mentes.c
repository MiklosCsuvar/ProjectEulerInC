#include <stdlib.h>
#include "CsM_math.h"

CsM_PrimeFactorsUll* CsM_PrimeFactorisationUll(ull number)
{
    CsM_PrimeFactorsUll PrFact;
    ull i = 0;

    PrFact.factor = CsM_PrimesUntilUll(number);
    while(PrFact.factor[meret]!=NULL) meret++;

    if(number==PrFact.factor[meret-1])
    {
        PrFact.meret    = 1;
        *PrFact.factor = number;
        *PrFact.power  = 1;
    }
    else
    {
        PrFact.power = (int)malloc(meret*sizeof(int));
        i = 0;
        while(i<meret)
        {
            PrFact.factor[i]=0;
            while(number%PrFact.factor[i]==0)
            {
                (PrFact.factor[i])++;
                number /= PrFact.factor[i]
            }
            i++;
        }
    }

    return PrFact;
}

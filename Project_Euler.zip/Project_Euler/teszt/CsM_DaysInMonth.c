int CsM_DaysInMonth(int year, int month)
{
    //Variables
    int daysinmonth[12] = {31,28,31,30,31,30,31,31,30,31,30,31};
    int result;
    //Calculation
    result = daysinmonth[month-1];
    if(month==2)
    {
        if(year%4==0)//Leap year
        {
            result = 29;
            if(year%100==0)//Non-leap year even so
            {
                result = 28;
                if(year%400==0) result = 29;//Leap year en so
            }
        }
    }
    //Result
    return result;
}

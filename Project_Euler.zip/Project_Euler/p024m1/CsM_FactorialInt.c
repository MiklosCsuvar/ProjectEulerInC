#include "CsM_Math.h"

unsigned long long FactorialInt(int n)
{
    if(n>1)
    {
        return n*FactorialInt(n-1);
    }
    else if(n>=0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

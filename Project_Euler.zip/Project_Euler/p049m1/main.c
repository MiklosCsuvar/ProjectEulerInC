/*
Prime permutations
Problem 49

The arithmetic sequence, 1487, 4817, 8147, in which each of the terms increases by 3330, is unusual in two ways:
(i) each of the three terms are prime, and,
(ii) each of the 4-digit numbers are permutations of one another.
There are no arithmetic sequences made up of three 1-, 2-, or 3-digit primes, exhibiting this property, but there is one other 4-digit increasing sequence.
What 12-digit number do you form by concatenating the three terms in this sequence?
*/

#include <stdio.h>
#include <stdlib.h>
#include "CsM_math.h"

int main()
{
    //Variables
    struct CsM_PrimesContainerUll* primes = (struct CsM_PrimesContainerUll*) malloc(sizeof(struct CsM_PrimesContainerUll));
    struct CsM_DynArrCh1D* useful = (struct CsM_DynArrCh1D*) malloc(sizeof(struct CsM_DynArrCh1D*));
    int i = 0;
    int j = 0;
    int k = 0;
    int primesusefulfrom = 0;

    //Calculation

    //1. Identiufying the primes until 9999.
    printf("Stage 1 start\n");
    CsM_PrimesUntilUll(primes,  9999);
//    for(i = 0; i < primes->lengthofarray; i++) {
//        printf("primes[%d]: %d\n", i, primes->factor[i]);
//    }
    printf("Stage 1 finished\n\n");

    //2. Constructing logical value container for the primes.
    printf("Stage 2 start\n");
    useful->lengthofarray = primes->lengthofarray;
    useful->content = (char*) malloc(sizeof(char)*(useful->lengthofarray));
    printf("Stage 2 finished\n\n");

    //3. Setting the container to 'true'.
    printf("Stage 3 start\n");
    for(i = 0; i < useful->lengthofarray; i++)
    {
        useful->content[i] = 1;
        printf("%d: primes: %d, useful: %d;\n", i, (int)primes->factor[i], (int)useful->content[i]);
    }
    printf("Stage 3 finished\n\n");

    //4. Setting the container to 'false' for primes below 1001.
    printf("Stage 4 start\n");
    i = 0;
    while(primes->factor[i] < 1001)
    {
        useful->content[i] = 0;
        printf("%d: primes: %d, useful: %d;\n",i, (int)primes->factor[i], (int)useful->content[i]);
        i++;
    }
    primesusefulfrom = i;
    printf("Primesusefulfrom = %d, primes: %d, useful: %d;\n",primesusefulfrom, (int)primes->factor[primesusefulfrom], (int)useful->content[primesusefulfrom]);
    printf("Stage 4 finished\n\n");

    //5. Iterating through the proper primes:
    printf("Stage 5 start\n");
    printf("%d: primes->lengthofarray: %d, useful->lengthofarray: %d\n", i, (int)primes->lengthofarray, (int)useful->lengthofarray);

    for(i = primesusefulfrom; i < primes->lengthofarray-2; i++)
    {
        while(i < primes->lengthofarray-3 && useful->content[i] == 0) i++;
        for(j = i+1; j < primes->lengthofarray-1; j++)
        {
            while(j < primes->lengthofarray-2 && useful->content[j] == 0) j++;
            for(k = j+1; k < primes->lengthofarray; k++)
            {
                while(k < primes->lengthofarray-1 && useful->content[k] == 0) k++;
                if(CsM_AreAnagramNumbersInt((int)primes->factor[i],(int)primes->factor[j]) &&
                        CsM_AreAnagramNumbersInt((int)primes->factor[j],(int)primes->factor[k]) &&
                    primes->factor[j] - primes->factor[i] == primes->factor[k] - primes->factor[j])
                {
                    printf("Primes at index %4d, %4d, %4d are %I64d, %I64d, %I64d\n", i, j, k, primes->factor[i], primes->factor[j], primes->factor[k]);
                }
            }
        }
    }
    printf("Stage 5 finished\n");

    //Printing result
    //printf("Primes at index %4d, %4d, %4d are %I64d, %I64d, %I64d\n", i, j, k, primes->factor[i], primes->factor[j], primes->factor[k]);
    //printf("The 12-digit number: %I64d, %I64d, %I64d\n", primes->factor[i],primes->factor[j],primes->factor[k]);

    //Freeing memory
    free(useful);
    free(primes);

    return 0;
}



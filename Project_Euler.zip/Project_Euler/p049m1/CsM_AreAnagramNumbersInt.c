#define __USE_MINGW_ANSI_STDIO 1
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "CsM_math.h"

int CsM_AreAnagramNumbersInt(int number1, int number2)
{
    int digits1[] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    int digits2[] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    int i = 0;

    //printf("CsM_AreAnagramNumbersInt start.\n");
    //printf("CsM_AreAnagramNumbersInt: %d %d.\n", number1, number2);
    if(number1 == number2) return 0;
    if(number1 == 0 || number2 == 0) return 0;

    //printf("CsM_AreAnagramNumbersInt number1.\n");
    if(number1 > 0)
    {
        while(number1 > 0)
        {
            digits1[number1%10]++;
            number1 /= 10;
        }
    }

    //printf("CsM_AreAnagramNumbersInt number2.\n");
    if(number2 > 0)
    {
        while(number2 > 0)
        {
            digits2[number2%10]++;
            number2 /= 10;
        }
    }

    //printf("CsM_AreAnagramNumbersInt comparison.\n");
    for(i = 0; i < 10; i++)
    {
        if(digits1[i] != digits2[i])
        {
            return 0;
        }
    }

    //Checking the function
//    for(i = 0; i < 10; i++) {
//        printf("%d %d\n", digits1[i], digits2[i]);
//    }

    //printf("CsM_AreAnagramNumbersInt successfull.\n");

    return 1;
}

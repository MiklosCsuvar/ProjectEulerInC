#define __USE_MINGW_ANSI_STDIO 1
#include <stdlib.h>
#include <stdio.h>
#include "CsM_math.h"
/*
The function get 2 input parameter:
 1. a pointer to a structure of an unsigned long long number, a long long number and an unsigned long long pointer,
 2. an unsigned long long number not greater than the primes are looked for.
The number, the count of primes and the primes themself are stored in the structure pointed to.
*/
void CsM_PrimesUntilUll(struct CsM_PrimesContainerUll *ptr, ull limit)
{
    printf("CsM_PrimesUntilUll running.\n");//Functioning checking.

    ptr->number = limit;

    if(ptr->number < 2)
    {
        ptr->lengthofarray = 0;
        ptr->factor = NULL;
    }
    else if(ptr->number == 2)
    {
        ptr->lengthofarray = 1;
        ptr->factor = (ull*)calloc(ptr->lengthofarray, sizeof(ull));//Allocating memory for the only prime 2..
        ptr->factor[0] = 2;
    }
    else if(ptr->number == 3)
    {
        ptr->lengthofarray = 2;
        ptr->factor = (ull*)calloc(ptr->lengthofarray, sizeof(ull));//Allocating memory for the primes 2 and 3.
        ptr->factor[0] = 2;
        ptr->factor[1] = 3;
    }
    else
    {
        CsM_PrimesUntilUllGreaterThan3(ptr);
    }

    //Functioning checking.
//    printf("CsM_PrimesUntilUll results:\n");
//    printf(" ptr->number: %llu\n",ptr->number);
//    printf(" ptr->lengthofarray: %lld\n",ptr->lengthofarray);
//    printf(" ptr->factor: ");
//    int i = 0;
//    while(i<ptr->lengthofarray)
//    {
//        printf("%lld ",ptr->factor[i++]);
//    }
//    printf("\n");

    return;
}

#ifndef CSM_MATH_H_INCLUDED
#define CSM_MATH_H_INCLUDED

//Type definitions
typedef unsigned long long ull;

//Structure definitions
struct CsM_DynArrCh1D
{
    long long lengthofarray;
    char* content;
};

struct CsM_DynArrInt1D
{
    long long lengthofarray;
    int* content;
};

struct CsM_DynArrIntND
{
    long dimension;
    long long *lengthofarray;
    int* content;
};

struct CsM_DynArrInt2DGeneral
{
    long long numberoflines;
    long long *sizeoflines;
    int** content;
};

struct CsM_DynArrLld2DGeneral
{
    long long numberoflines;
    long long *sizeoflines;
    long long** number;
};

struct CsM_DynArrUll1D
{
    long long lengthofarray;
    ull* number;
};
struct CsM_HugeNumber
{
    signed char ascending;
    signed char sign;
    long long lengthofarray;
    long long numberofdecimals;
    char *content;
};

struct CsM_PrimeFactorsUll
{
    ull number;
    long long lengthofarray;
    ull* factor;
    int* power;
};

struct CsM_PrimesContainerUll
{
    ull number;
    long long lengthofarray;
    ull* factor;
};

struct CsM_SequenceUll
{
    ull lengthofarray;
    ull* sequence;
};

//Function declarations
int CsM_AreAnagramNumbersInt(int, int);
int CsM_IsMadeOfDistinctInt(int);
ull FactorialInt(int);
struct CsM_DynArrLld2DGeneral CsM_FileToDynArrLld2DGeneral(FILE *);
long long CsM_GreatestProductInArrLong2D(long**, long, long, long);
long long CsM_GreatestProductInLineInt(int *, ull, ull);
int CsM_IsPalindromeInBaseUll(ull, ull);
ull CsM_LeastCommonMultiple(ull*, ull);
struct CsM_DynArrInt1D CsM_LexicographicPermutation(int, ull);
ull CsM_MaxUll(ull*, ull);
ull CsM_NumberOfDivisors(struct CsM_PrimeFactorsUll*);
ull CsM_PowerUll(ull, ull);
struct CsM_PrimeFactorsUll CsM_PrimeFactorisationUll(ull, struct CsM_DynArrUll1D*);
void CsM_PrimeFactorisationUll_v2(struct CsM_PrimesContainerUll*, struct CsM_PrimeFactorsUll*);
void CsM_PrimesUntilUll(struct CsM_PrimesContainerUll*, ull);
void CsM_PrimesUntilUllExpand_v1(struct CsM_PrimesContainerUll*, ull);
void CsM_PrimesUntilUllGreaterThan3(struct CsM_PrimesContainerUll*);
struct CsM_PrimeFactorsUll* CsM_ProductOfPrimeFactorisationsUll_v1(struct CsM_PrimeFactorsUll*, struct CsM_PrimeFactorsUll*);
struct CsM_DynArrCh1D CsM_RevProdOfRevChArr(struct CsM_DynArrCh1D, struct CsM_DynArrCh1D);
struct CsM_SequenceUll CsM_CollatzUll(ull);

#endif // CSM_MATH_H_INCLUDED

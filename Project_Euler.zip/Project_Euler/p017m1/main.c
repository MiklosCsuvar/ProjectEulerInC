/*
Number letter counts
Problem 17

If the numbers 1 to 5 are written out in words: one, two, three, four, five, then there are 3 + 3 + 5 + 4 + 4 = 19 letters used in total.

If all the numbers from 1 to 1000 (one thousand) inclusive were written out in words, how many letters would be used?

NOTE: Do not count spaces or hyphens. For example, 342 (three hundred and forty-two) contains 23 letters and 115 (one hundred and fifteen) contains 20 letters. The use of "and" when writing out numbers is in compliance with British usage.
*/
#define __USE_MINGW_ANSI_STDIO 1
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int main()
{
    //Variables
    int i = 0, j = 0, tmpint1 = 0, tmpint2 = 0;
    long result = 0;
    long tmp = 0;
    char str1[32];
    char str2[32];
    char *pstr1 = &str1[0];
    char *pstr2 = &str2[0];

    //Conversion cycles
    for(i = 1; i < 1001; i++)
    {
        //Variable resetting
        for(j = 0; j<32;j++)
        {
            str1[j] = '\0';
            str2[j] = '\0';
        }
        tmpint1 = 0;
        tmpint2 = 0;

        //Calculation
        tmpint1 = i;
        printf("\n\ni = %d:\n", i);

        //Processing thousand
        if(tmpint1/1000)
        {
            strcpy(str2,"one thousand");
            strcat(pstr1, pstr2);
            tmpint1 %= 1000;
        }

        //Procerssing the hundreds
        tmpint2 = tmpint1/100;
        //printf(" tmpint1 = %d\n", tmpint1);
        //printf(" tmpint2 = %d\n", tmpint2);
        //printf("%d: Success.\n", __LINE__);
        if(tmpint2)
        {
            switch(tmpint2)
            {
            case 9:
                strcpy(pstr2,"nine");
                break;
            case 8:
                strcpy(pstr2,"eight");
                break;
            case 7:
                strcpy(pstr2,"seven");
                break;
            case 6:
                strcpy(pstr2,"six");
                break;
            case 5:
                strcpy(pstr2,"five");
                break;
            case 4:
                strcpy(pstr2,"four");
                break;
            case 3:
                strcpy(pstr2,"three");
                break;
            case 2:
                strcpy(pstr2,"two");
                break;
            case 1:
                strcpy(pstr2,"one");
                break;
            default:
                printf("Unknown failure.\n");
            }
            strcat(pstr1, pstr2);
            strcat(pstr1, " hundred");
            //printf(" str1 = %s\n", str1);
            for(j = 0; j<32;j++) str2[j] = '\0';
        }

        //printf(" tmpint1 = %d\n", tmpint1);
        //printf(" tmpint2 = %d\n", tmpint2);
        //printf("%d: Success.\n", __LINE__);

        //Procerssing the tens and ones
        tmpint2 = tmpint1%100;
        if(tmpint1/100 > 0 && tmpint2 > 0) strcat(str1, " and ");
        //printf(" tmpint1 = %d\n", tmpint1);
        //printf(" tmpint2 = %d\n", tmpint2);
        //printf("%d: Success.\n", __LINE__);
        //
        if(tmpint2 > 19)
        {
            printf(" tmpint2 > 19\n");
            for(j = 0; j<32;j++) str2[j] = '\0';
            tmpint2 /=10;
            printf("  tmpint2 = %d\n", tmpint2);
            switch(tmpint2)
            {
            case 9:
                strcpy(pstr2,"ninety");
                break;
            case 8:
                strcpy(pstr2,"eighty");
                break;
            case 7:
                strcpy(pstr2,"seventy");
                break;
            case 6:
                strcpy(pstr2,"sixty");
                break;
            case 5:
                strcpy(pstr2,"fifty");
                break;
            case 4:
                strcpy(pstr2,"forty");
                break;
            case 3:
                strcpy(pstr2,"thirty");
                break;
            case 2:
                strcpy(pstr2,"twenty");
                break;
            default:
                printf("Failure between 20 and 99.\n");
            }
            strcat(pstr1, pstr2);
            printf("  str1: %s\n", pstr1);
            for(j = 0; j<32;j++) str2[j] = '\0';

            //Processing ones
            tmpint2 = tmpint1%10;
            //printf(" tmpint1 = %d\n", tmpint1);
            printf(" tmpint2 = %d\n", tmpint2);
            //printf("%d: Success.\n", __LINE__);
            if(tmpint2) strcat(pstr1, "-");
            switch(tmpint2)
            {
            case 9:
                strcpy(pstr2,"nine");
                break;
            case 8:
                strcpy(pstr2,"eight");
                break;
            case 7:
                strcpy(pstr2,"seven");
                break;
            case 6:
                strcpy(pstr2,"six");
                break;
            case 5:
                strcpy(pstr2,"five");
                break;
            case 4:
                strcpy(pstr2,"four");
                break;
            case 3:
                strcpy(pstr2,"three");
                break;
            case 2:
                strcpy(pstr2,"two");
                break;
            case 1:
                strcpy(pstr2,"one");
                break;
            default:
                printf("Failure between 1 and 9 and above 19.\n");
            }
            strcat(pstr1, pstr2);
            printf("  str1: %s\n", pstr1);
        }
        else
        {
            printf(" tmpint2 < 20");
            for(j = 0; j<32;j++) str2[j] = '\0';
            //printf(" tmpint1 = %d\n", tmpint1);
            //printf(" tmpint2 = %d\n", tmpint2);
            //printf("%d: Success.\n", __LINE__);
            switch(tmpint2)
            {
            case 19:
                strcpy(str2,"nineteen");
                break;
            case 18:
                strcpy(str2,"eighteen");
                break;
            case 17:
                strcpy(str2,"seventeen");
                break;
            case 16:
                strcpy(str2,"sixteen");
                break;
            case 15:
                strcpy(str2,"fifteen");
                break;
            case 14:
                strcpy(str2,"fourteen");
                break;
            case 13:
                strcpy(str2,"thirteen");
                break;
            case 12:
                strcpy(str2,"twelve");
                break;
            case 11:
                strcpy(str2,"eleven");
                break;
            case 10:
                strcpy(str2,"ten");
                break;
            case 9:
                strcpy(str2,"nine");
                break;
            case 8:
                strcpy(str2,"eight");
                break;
            case 7:
                strcpy(str2,"seven");
                break;
            case 6:
                strcpy(str2,"six");
                break;
            case 5:
                strcpy(str2,"five");
                break;
            case 4:
                strcpy(str2,"four");
                break;
            case 3:
                strcpy(str2,"three");
                break;
            case 2:
                strcpy(str2,"two");
                break;
            case 1:
                strcpy(str2,"one");
                break;
            default:
                printf("Failure between 1 and 9 and below 20.\n");
            }

            if(i == 0) strcpy(pstr2, "zero");
            //printf("%d: Success.\n", __LINE__);
            //printf(" str1: %s\n", str1);
            //printf("%d: Success.\n", __LINE__);
            strcat(pstr1, pstr2);
            //printf("%d: Success.\n", __LINE__);
            printf(" str1: %s\n", pstr1);
            for(j = 0; j<32;j++) str2[j] = '\0';
        }
        //printf(" %d: Success.\n", __LINE__);
        tmp = 0;
        j = 0;
        while(str1[j] != '\0') if(isalpha(str1[j++])) tmp++;
        result += tmp;
        printf(" %d: str1 = %s\n", i, pstr1);
        printf("     count of numbers = %ld\n", tmp);
    }

    //Printing results
    printf("\nNumber letter count = %ld", result);

    return 0;
}

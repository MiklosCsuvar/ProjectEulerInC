#define __USE_MINGW_ANSI_STDIO 1
#include <stdio.h>
#include <stdlib.h>
#include "CsM_math.h"

/*
The function
 get a structure of the result of a number's prime factorisation and
 return the number of divisors of the number.
*/

ull CsM_NumberOfDivisors(struct CsM_PrimeFactorsUll *ptr)
{
    long long i;
    ull result = 1;

    //Printing input
    /*printf("\n\nCsM_NumberOfDivisors running.\n");
    printf(" ptr->number: %llu\n",ptr->number);
    printf(" meret = %lld\n",ptr->meret);
    printf(" primes^factors:");
    for(i=0; i<ptr->meret; i++) printf(" %llu^%d",ptr->factor[i],ptr->power[i]);
    //for(i=0; i<ptr->meret; i++) printf(" %llu",i);
    printf("\n");*/

    switch(ptr->number)
    {
    case 0:
        result = 1;
        break;
    case 1:
        result = 1;
        break;
    default:
        for(i=0; i<ptr->meret; i++) if(ptr->factor[i] > 1) result *= (ptr->power[i]+1);
    }

    return result;
}

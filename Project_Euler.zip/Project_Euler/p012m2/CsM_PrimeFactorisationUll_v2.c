#define __USE_MINGW_ANSI_STDIO 1
#include <stdio.h>
#include <stdlib.h>
#include "CsM_math.h"

/*
The function produce the prime factorisation of a number.
It get
 1 pointer to a structure of prime factors, not necessarily greater than the number to factorise,
 1 pointer to a structure of the number to factorise and to store the results.
*/

void CsM_PrimeFactorisationUll_v2(struct CsM_PrimesUntilUll* primes, struct CsM_PrimeFactorsUll* number)
{
    printf("\n\nCsM_PrimeFactorisationUll_v2 running.\n");

    //Variables
    ull i = 0;
    ull j = 0;
    ull tmpnumber = number->number;

    /*
    //Printing input
    printf(" Printing input\n");
    printf("  primes->number: %llu\n",primes->number);
    printf("  primes^factors:");
    for(i = 0; i<primes->meret; i++) printf(" %llu",primes->factor[i]);
    printf("\n");
    */

    //Resetting result variables
    number->meret  = 0;
    number->factor = NULL;
    number->power  = NULL;

    if(number->number > primes->number) CsM_PrimesUntilUllExpand_v1(primes, number->number);
    /*
    //Printing expansion
    printf(" Printing expansion\n");
    printf("  primes->number: %llu\n",primes->number);
    printf("  primes^factors:");
    for(i = 0; i<primes->meret; i++) printf(" %llu",primes->factor[i]);
    printf("\n");
    */

    //Factorising "number" (a.k.a. "tmpnumber") via auxiliary primes.
    if(number->number < 3)
    {
        number->meret = 1;
        //Resetting structure
        free(number->factor);
        free(number->power);
        number->factor = (ull*)calloc(1, sizeof(ull));
        number->power  = (int*)calloc(1, sizeof(int));
        number->power[0] = 1;
        if(number->number == 0)
        {
            number->factor[0] = 0;
        }
        else if(number->number == 1)
        {
            number->factor[0] = 1;
        }
        else
        {
            number->factor[0] = 2;
        }
    }
    else
    {
        for(i=0; i<primes->meret; i++)
        {
            //Testing variable "tmpnumber" for the available primes.
            if(tmpnumber%primes->factor[i] == 0)
            {
                if(number->meret == 0)
                {
                    number->meret = 1;
                    number->factor = (ull*)calloc(1, sizeof(ull));
                    number->power  = (int*)calloc(1, sizeof(int));
                }
                else
                {
                    number->meret++;
                    number->factor = (ull*)realloc(number->factor, number->meret*sizeof(ull));
                    number->power  = (int*)realloc(number->power, number->meret*sizeof(int));
                    number->factor[number->meret-1] = 0;
                    number->power[number->meret-1] = 0;
                }
                //printf(" number->meret = %lld\n",number->meret);
                number->factor[j] = primes->factor[i];
                //printf(" j = %llu\n",j);
                while(tmpnumber%number->factor[j]==0)
                {
                    //If "tmpnumber" is divisible, power is calculated.
                    //printf(" tmpnumber = %llu\n",tmpnumber);
                    //printf(" number->factor[%llu] = %llu\n",j,number->factor[j]);
                    tmpnumber /= (number->factor[j]);//Avoiding testing for all primes until "number".
                    number->power[number->meret-1] += 1;
                    //printf(" number->power[%lld] = %d\n",number->meret-1,number->power[number->meret-1]);
                    //printf(" %llu^%d\n",number->factor[j],number->power[j]);
                    //printf(" new tmpnumber = %llu, primes->factor^primes->power = %llu^%d\n", tmpnumber, number->factor[j],number->power[j]);
                    if(tmpnumber==1) break; //If factorising result in 1, no further prime checking needed.
                }
                j++;
            }
        }
    }
    /*
    //Results printing
    printf(" Results:\n");
    printf("  number->number: %llu\n",number->number);
    printf("  primes^factors:");
    for(i=0; i<number->meret; i++) printf(" %llu^%d", number->factor[i], number->power[i]);
    printf("\n");
    */
    return;
}

#define __USE_MINGW_ANSI_STDIO 1
#include <stdio.h>
#include <stdlib.h>
#include "CsM_math.h"

/*
The function produce the prime numbers above Number1 until Number2, if Number2 > Number1.
The function get 2 input parameter:
 1. a pointer to a structure of an unsigned long long number, a long long number and an unsigned long long pointer,
 2. an unsigned long long number not greater than the primes are looked for.
The number, the count of primes and the primes themself are updated and stored in the structure pointed to.
*/

void CsM_PrimesUntilUllExpand_v1(struct CsM_PrimesUntilUll *ptr, ull number)
{
    printf("\n\nCsM_PrimesUntilUllExpand_v1 running.\n");

    //Variables.
    ull oddnumber;//Odd number under examination to be a prime.
    ull i;//Running index.
    ull j;//Running index.

    if(number > ptr->number)//Is it necessary to examine the existence of additional primes?
    {

        if(number < 3)
        {
            //Resetting prime number storage structure.
            ptr->number = 0;
            ptr->meret = 0;
            free(ptr->factor);
            ptr->factor = NULL;
            //Producing primes numbers.
            CsM_PrimesUntilUll(ptr, number);
        }
        else
        {
            if(ptr->number < 3)
            {
                //If the original greatest prime was under 3, the structure is reseted, because the
                //the algorithm assume, the new prime calculation start at an odd number.
                //Resetting prime number storage structure.
                ptr->number = 0;
                ptr->meret = 0;
                free(ptr->factor);
                ptr->factor = NULL;
                //Producing primes numbers.
                CsM_PrimesUntilUll(ptr, 3);
            }
            ptr->number = number;//Setting the new, greater number.
            //Prime searching.
            i = ptr->meret;
            j = 0;
            oddnumber = ptr->factor[i-1] + 2;//Next odd number to examine.
            while(oddnumber<=ptr->number)
            {
                //printf("oddnumber = %llu\n",oddnumber);
                //Analysing all the known primes stored.
                while(j<i)
                {
                    if(oddnumber%ptr->factor[j]==0)//If the number can be divided by the prime, the number is not a prime.
                    {
                        j = 0;//Resetting cycle.
                        oddnumber += 2;//Next odd number.
                        break;//Restarting cycle.
                    }
                    else//Next prime to check to be a divisor of the odd number.
                    {
                        j++;
                    }
                }
                /*If none of the previous numbers can divide the odd number, it is a prime
                below 'number'.*/
                if(j==i)
                {
                    ptr->factor = (ull *)realloc(ptr->factor, (i+1)*sizeof(ull));//Memory allocation for next prime.
                    ptr->factor[i++] = oddnumber;//Odd number is stored. Count of primes is increased.
                    ptr->meret = i;
                    j = 0;//Resetting cycle.
                    oddnumber += 2;//Next odd number.
                }
            }

        }
    }
    return;
}

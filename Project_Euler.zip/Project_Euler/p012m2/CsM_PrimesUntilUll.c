#define __USE_MINGW_ANSI_STDIO 1
#include <stdlib.h>
#include <stdio.h>
#include "CsM_math.h"
/*
The function get 2 input parameter:
 1. a pointer to a structure of an unsigned long long number, a long long number and an unsigned long long pointer,
 2. an unsigned long long number not greater than the primes are looked for.
The number, the count of primes and the primes themself are stored in the structure pointed to.
*/
void CsM_PrimesUntilUll(struct CsM_PrimesUntilUll *ptr, ull number)
{
    printf("\n\nCsM_PrimesUntilUll running.\n");//Functioning checking.
    //Variables

    if(ptr == NULL)
    {
        printf("CsM_PrimesUntilUll: NULL pointer. Pointer must be initialized before first use.\n");
    }
    else
    {
        ptr->number = number;
        if(ptr->number < 2)
        {
            ptr->meret = 0;
            ptr->factor = NULL;
        }
        else if(ptr->number == 2)
        {
            ptr->meret = 1;
            ptr->factor = (ull*)calloc(ptr->meret, sizeof(ull));//Allocating memory for the primes.
            ptr->factor[0] = 2;
        }
        else if(ptr->number == 3)
        {
            ptr->meret = 2;
            ptr->factor = (ull*)calloc(ptr->meret, sizeof(ull));//Allocating memory for the primes.
            ptr->factor[0] = 2;
            ptr->factor[1] = 3;
        }
        else
        {
            CsM_PrimesUntilUllGreaterThan3(ptr);
        }
    }
/*
    //Functioning checking.
    printf("CsM_PrimesUntilUll results:\n");
    printf(" ptr->number: %llu\n",ptr->number);
    printf(" ptr->meret: %lld\n",ptr->meret);
    printf(" ptr->factor: ");
    while(i<ptr->meret)
    {
        printf("%lld ",ptr->factor[i++]);
    }
    printf("\n");
*/
    return;
}

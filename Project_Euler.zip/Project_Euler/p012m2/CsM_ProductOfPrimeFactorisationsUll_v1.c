#define __USE_MINGW_ANSI_STDIO 1
#include <stdlib.h>
#include <stdio.h>
#include "CsM_math.h"

struct CsM_PrimeFactorsUll* CsM_ProductOfPrimeFactorisationsUll_v1(struct CsM_PrimeFactorsUll *pfac0, struct CsM_PrimeFactorsUll *pfac1)
{
    long long i = 0;
    long long limitindex[2] = {0,0};//Temporary limit index.
    struct CsM_PrimeFactorsUll *pfacres = NULL;
    pfacres = calloc(1, sizeof(struct CsM_PrimeFactorsUll));
    pfacres->number = pfac0->number*pfac1->number;//Product of 2 factors had been factorised.

    /*
    printf("\n\nCsM_ProductOfPrimeFactorisationsUll_v1 running:\n");
    printf("Input:\n");
    printf(" a = %llu\n",pfac0->number);
    printf("  size = %lld\n",pfac0->meret);
    printf("  factor^power: ");
    for(i = 0; i<pfac0->meret; i++) printf("%llu^%d ",pfac0->factor[i],pfac0->power[i]);
    printf("\n");
    printf(" b = %llu\n",pfac1->number);
    printf("  size = %lld\n",pfac1->meret);
    printf("  factor^power: ");
    for(i = 0; i<pfac0->meret; i++) printf("%llu^%d ",pfac1->factor[i],pfac1->power[i]);
    printf("\n\n");
    */

    while(limitindex[0] < pfac0->meret || limitindex[1] < pfac1->meret)
    {
        /*printf("\nKeep going? ");
        scanf("%c",&c);
        if(c == '0') break;
        printf("\n");*/

        pfacres->meret++;
        /*printf(" pfacres->meret = %lld\n",pfacres->meret);
        printf(" limitindex[0] < pfac0->meret || limitindex[1] < pfac1->meret\n");
        printf(" %lld          < %lld         || %lld          < %lld\n", limitindex[0], pfac0->meret, limitindex[1], pfac1->meret);*/

        //Memory allocation and setting to zero.
        if(pfacres->meret == 1)
        {
            pfacres->factor = calloc(1, sizeof(ull));
            pfacres->power  = calloc(1, sizeof(int));
        }
        else
        {
            pfacres->factor = realloc(pfacres->factor, pfacres->meret*sizeof(ull));
            pfacres->factor[pfacres->meret-1] = 0;
            pfacres->power  = realloc(pfacres->power, pfacres->meret*sizeof(int));
            pfacres->power[pfacres->meret-1] = 0;
        }

        //Result for 0.
        if(pfacres->number == 0)
        {
            pfacres->factor[0] = 0;
            pfacres->power[0] = 1;
            break;//No need for further work.
        }

        //Producing the prime factorisation of product of factors.
        if(limitindex[0] < pfac0->meret && limitindex[1] < pfac1->meret)
        {
            if(pfac0->factor[limitindex[0]] < pfac1->factor[limitindex[1]])
            {
                /*printf("Sor: %d\n", __LINE__);
                printf(" limitindex[0] = %lld\n",limitindex[0]);
                printf(" pfac0->factor[%lld] = %llu\n",limitindex[0],pfac0->factor[limitindex[0]]);
                printf(" limitindex[1] = %lld\n",limitindex[1]);
                printf(" pfac1->factor[%lld] = %llu\n",limitindex[1],pfac1->factor[limitindex[1]]);
                printf(" pfacres->factor[%lld] = %llu\n",pfacres->meret-1,pfacres->factor[pfacres->meret-1]);
                printf(" pfacres->powerr[%lld] = %llu\n",pfacres->meret-1,pfacres->power[pfacres->meret-1]);*/
                pfacres->factor[pfacres->meret-1] = pfac0->factor[limitindex[0]];
                pfacres->power[pfacres->meret-1] = pfac0->power[limitindex[0]];
                if(limitindex[0] < pfac0->meret) limitindex[0]++;
                /*printf("Sor: %d\n", __LINE__);
                printf(" limitindex[0] = %lld\n",limitindex[0]);
                printf(" pfac0->factor[%lld] = %llu\n",limitindex[0],pfac0->factor[limitindex[0]]);
                printf(" limitindex[1] = %lld\n",limitindex[1]);
                printf(" pfac1->factor[%lld] = %llu\n",limitindex[1],pfac1->factor[limitindex[1]]);
                printf(" pfacres->factor[%lld] = %llu\n",pfacres->meret-1,pfacres->factor[pfacres->meret-1]);
                printf(" pfacres->powerr[%lld] = %llu\n",pfacres->meret-1,pfacres->power[pfacres->meret-1]);*/

                //Search for power of the same factor identified in above line.
                /*i = limitindex[1];//Search start at power of factors not used before.
                while(i < pfac1->meret && pfac1->factor[i] <= pfacres->factor[pfacres->meret-1])
                {
                    if(pfac1->factor[i] == pfacres->factor[pfacres->meret-1])
                    {
                        pfacres->power[pfacres->meret-1] += pfac1->power[i];
                        limitindex[1]++;//The factor and its power have been used. Next search start at index greater by 1.
                        break;
                    }
                    i++;
                }*/
            }
            else if(pfac0->factor[limitindex[0]] > pfac1->factor[limitindex[1]])
            {
                //printf(" limitindex[1] = %lld\n",limitindex[1]);
                //printf("pfacres->factor[%lld] = %llu\n",pfacres->meret-1,pfacres->factor[pfacres->meret-1]);
                //printf("  pfac1->factor[%lld] = %llu\n",limitindex[1],pfac1->factor[limitindex[1]]);
                pfacres->factor[pfacres->meret-1] = pfac1->factor[limitindex[1]];
                pfacres->power[pfacres->meret-1] = pfac1->power[limitindex[1]];
                if(limitindex[1] < pfac1->meret) limitindex[1]++;
                //Search for power of the same factor identified in above line.
                /*i = limitindex[0];//Search start at power of factors not used before.
                while(i < pfac0->meret && pfac0->factor[i] <= pfacres->factor[pfacres->meret-1])
                {
                    if(pfac0->factor[i] == pfacres->factor[pfacres->meret-1])
                    {
                        pfacres->power[pfacres->meret-1] += pfac0->power[i];
                        limitindex[0]++;//The factor and its power have been used. Next search start at index greater by 1.
                        break;
                    }
                    i++;
                }*/
            }
            else if(pfac0->factor[limitindex[0]] == pfac1->factor[limitindex[1]])
            {
                /*printf(" limitindex[0] < pfac0->meret || limitindex[1] < pfac1->meret\n");
                printf(" %lld          < %lld         || %lld          < %lld\n", limitindex[0], pfac0->meret, limitindex[1], pfac1->meret);
                printf("  pfac0->factor[%lld] = %llu\n",limitindex[0],pfac0->factor[limitindex[0]]);
                printf("  pfac1->factor[%lld] = %llu\n",limitindex[1],pfac1->factor[limitindex[1]]);*/
                pfacres->factor[pfacres->meret-1] = pfac1->factor[limitindex[1]];
                pfacres->power[pfacres->meret-1] = pfac0->power[limitindex[0]]+pfac1->power[limitindex[1]];
                limitindex[0]++;
                limitindex[1]++;
            }
            else
            {
                printf(" Function CsM_ProductOfPrimeFactorisationsUll_v1: Non-handled exception 1.\n");
                printf(" limitindex[0] < pfac0->meret || limitindex[1] < pfac1->meret\n");
                printf(" %lld          < %lld         || %lld          < %lld\n", limitindex[0], pfac0->meret, limitindex[1], pfac1->meret);
                printf("  pfac0->factor[%lld] = %llu\n",limitindex[0],pfac0->factor[limitindex[0]]);
                printf("  pfac1->factor[%lld] = %llu\n",limitindex[1],pfac1->factor[limitindex[1]]);

            }
        }
        else if(limitindex[0] < pfac0->meret)
        {
            pfacres->factor[pfacres->meret-1] += pfac0->factor[limitindex[0]];
            pfacres->power[pfacres->meret-1] += pfac0->power[limitindex[0]];
            limitindex[0]++;//The factor and its power have been used. Next search start at index greater by 1.
        }
        else if(limitindex[1] < pfac1->meret)
        {
            pfacres->factor[pfacres->meret-1] += pfac1->factor[limitindex[1]];
            pfacres->power[pfacres->meret-1] += pfac1->power[limitindex[1]];
            limitindex[1]++;//The factor and its power have been used. Next search start at index greater by 1.
        }
        else
        {
            printf(" Function CsM_ProductOfPrimeFactorisationsUll_v1: Non-handled exception 2.\n");
            printf("  pfac0->factor[%lld] = %llu\n",limitindex[0],pfac0->factor[limitindex[0]]);
            printf("  pfac1->factor[%lld] = %llu\n",limitindex[1],pfac1->factor[limitindex[1]]);
        }
        /*printf("Output:\n");
        printf(" number = %llu\n",pfacres->number);
        printf("  size = %lld\n",pfacres->meret);
        printf("  factor^power:");
        for(i = 0; i<pfacres->meret; i++) printf(" %llu^%d ",pfacres->factor[i],pfacres->power[i]);
        printf("\n\n");*/
    }

    printf("Result:\n");
    printf(" number = %llu\n",pfacres->number);
    printf("  size = %lld\n",pfacres->meret);
    printf("  factor^power:");
    for(i = 0; i<pfacres->meret; i++) printf(" %llu^%d ",pfacres->factor[i],pfacres->power[i]);
    printf("\n\n");
    return pfacres;
}

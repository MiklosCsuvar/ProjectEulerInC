#define __USE_MINGW_ANSI_STDIO 1
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "CsM_math.h"

/*
It get a pointer of a structure of
 1 unsigned long long,
 1 long long int,
 1 pointer to unsigned long long.
It calculate and store the prime numbers until the unsigned long long stored in the structure.
*/

void CsM_PrimesUntilUllGreaterThan3(struct CsM_PrimesUntilUll *ptr)
{
    //Functioning checking.
    //printf("CsM_PrimesUntilUllGreaterThan3 running\n");
    //printf("ptr->number = %llu\n", ptr->number);

    //Variables.
    ull oddnumber;//Odd number under examination to be a prime.
    ull i;//Running index.
    ull j;//Running index.

    //Base settings of output not demanding calculation.
    ptr->meret = 2;
    ptr->factor = (ull*)calloc(ptr->meret, sizeof(ull));//Allocating memory for the primes.
    ptr->factor[0] = 2;//1st prime number.
    ptr->factor[1] = 3;//2nd prime number.

    //Prime searching.
    i = 2;
    j = 0;
    oddnumber = ptr->factor[1] + 2;//Next odd number to examine.
    while(oddnumber<=ptr->number)
    {
        //printf("i = %llu\n",oddnumber);
        //Analysing all the known primes stored.
        while(j<i)
        {
            if(oddnumber%ptr->factor[j]==0)//If the number can be divided by the prime, the number is not a prime.
            {
                j = 0;//Resetting cycle.
                oddnumber += 2;//Next odd number.
                break;//Restarting cycle.
            }
            else//Next prime to check to be a divisor of the odd number.
            {
                j++;
            }
        }
        /*If none of the previous numbers can divide the odd number, it is a prime
        below 'number'.*/
        if(j==i)
        {
            ptr->factor = (ull *)realloc(ptr->factor, (i+1)*sizeof(ull));//Memory allocation for next prime.
            ptr->factor[i++] = oddnumber;//Odd number is stored. Count of primes is increased.
            ptr->meret = i;
            j = 0;//Resetting cycle.
            oddnumber += 2;//Next odd number.
        }
    }
    return;
}

#include <stdio.h>
#include <stdlib.h>
#include "CsM_math.h"

struct CsM_PrimeFactorsUll CsM_PrimeFactorisationUll(ull number,  struct CsM_DynArrUll1D* primes)
{
    struct CsM_PrimeFactorsUll res;
    res.meret  = 0;
    res.factor = NULL;
    res.power  = NULL;
    ull i = 0;
    ull j = 0;
    ull tmp = 0;
    ull tmpnumber = number;

    //printf("Size: %llu\n",res.meret);

    if(primes==NULL)//No auxiliary primes. First factorisation must be done.
    {
        if(tmpnumber>1)
        {
            if(tmpnumber<3)
            {
                res.meret     = 1;
                res.factor[0] = 2;
                res.power[0]  = 1;
            }
            else
            {
                res.factor = (ull *)realloc(res.factor, 2*sizeof(ull));
                res.power  = (int *)realloc(res.power, 2*sizeof(int));
                res.meret  = 2;
                res.factor[0] = 2;
                res.factor[1] = 3;
                res.power[0]  = 0;
                res.power[1]  = 0;

                i = 0;
                while(tmpnumber>1)
                {
                    while(i<res.meret)
                    {
                        //Testing variable "tmpnumber" for the available primes.
                        //printf("Size: %llu\n",res.meret);
                        res.power[i] = 0;//Set power to default.
                        while(tmpnumber%res.factor[i]==0)
                        {
                            //If "tmpnumber" is divisible, power is alculated.
                            tmpnumber /= res.factor[i];//Avoiding testing for all primes until "number".
                            res.power[i]++;
                        }
                        //printf("%llu^%d\n",res.factor[i],res.power[i]);
                        i++;
                    }

                    if(tmpnumber!=1)//If factorisation not finished, find a new prime!
                    {
                        res.meret++;//Need for new prime. Memory allocated for factor candidate.
                        res.factor = (ull *)realloc(res.factor, res.meret*sizeof(ull));
                        res.power  = (int *)realloc(res.power, res.meret*sizeof(int));

                        j = 0;
                        tmp = res.factor[res.meret-2] + 2;//Candidate for prime.
                        while(j<i)
                        {
                            //Testing odd number "tmp" for being a prime.
                            if(tmp%res.factor[j]==0)
                            {
                                //"tmp" is divisible by a prime, therefore rejected.
                                j = 0;
                                tmp += 2;//New prime candidate.
                                break;
                            }
                            else
                            {
                                j++;//Stepping to next prime to test candidate.
                            }
                        }
                        if(j==i)//Candidate is a prime.
                        {
                            res.factor[i] = tmp;
                        }
                        continue;
                    }
                }
            }
        }
    }
    else //Auxiliary primes available. Factorisation on their base.
    {
        //Setting the result "res" to default.
        res.meret  = primes->meret;
        res.factor = (ull*)calloc(res.meret,sizeof(ull));
        for(i=0; i<res.meret; i++) res.factor[i] = primes->number[i];
        res.power  = (int*)calloc(res.meret,sizeof(int));
        for(i=0; i<res.meret; i++) res.power[i] = 0;//Set power to default.

        //Factorising "number" (a.k.a. "tmpnumber") via auxiliary primes.
        for(i=0; i<res.meret; i++)
        {
            //Testing variable "tmpnumber" for the available primes.
            //printf("Size: %llu\n",res.meret);
            while(tmpnumber%res.factor[i]==0)
            {
                //If "tmpnumber" is divisible, power is calculated.
                tmpnumber /= res.factor[i];//Avoiding testing for all primes until "number".
                res.power[i]++;
            }
            if(tmpnumber==0) break; //If factorising result in 1, no further prime checking needed.
            //printf("%llu^%d\n",res.factor[i],res.power[i]);
        }
    }

    /*
    //Output testing the function:
    printf("CsM_PrimeFactorisationUll:\n");
    printf("number = %llu\n",number);
    printf("Size: %llu\n",res.meret);
    i = 0;
    printf("Number = %llu^%d",res.factor[i],res.power[i]);
    i++;
    while(i<res.meret)
    {
        printf(" * %llu^%d",res.factor[i],res.power[i]);
        i++;
    }
    printf("\n\n");
    */
    return res;
}


/*
#include <stdlib.h>
#include "CsM_math.h"

CsM_PrimeFactorsUll* CsM_PrimeFactorisationUll(ull number)
{
    CsM_PrimeFactorsUll PrFact;
    ull i = 0;

    PrFact.factor = CsM_PrimesUntilUll(number);
    while(PrFact.factor[meret]!=NULL) meret++;

    if(number==PrFact.factor[meret-1])
    {
        PrFact.meret    = 1;
        *PrFact.factor = number;
        *PrFact.power  = 1;
    }
    else
    {
        PrFact.power = (int)malloc(meret*sizeof(int));
        i = 0;
        while(i<meret)
        {
            PrFact.factor[i]=0;
            while(number%PrFact.factor[i]==0)
            {
                (PrFact.factor[i])++;
                number /= PrFact.factor[i]
            }
            i++;
        }
    }

    return PrFact;
}
*/

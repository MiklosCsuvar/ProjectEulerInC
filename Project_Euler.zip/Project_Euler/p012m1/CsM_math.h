#ifndef CSM_MATH_H_INCLUDED
#define CSM_MATH_H_INCLUDED

typedef unsigned long long ull;

struct CsM_DynArrCh1D
{
    long long meret;
    int* character;
};

struct CsM_DynArrInt1D
{
    long long meret;
    int* number;
};

struct CsM_DynArrIntND
{
    long dimension;
    long long *meret;
    int* number;
};

struct CsM_DynArrLld2D
{
    long long meret[1][2];
    long long* number;
};

struct CsM_DynArrUll1D
{
    long long meret;
    ull* number;
};

struct CsM_PrimeFactorsUll
{
    ull number;
    long long meret;
    ull* factor;
    int* power;
};

struct CsM_PrimesUntilUll
{
    ull number;
    long long meret;
    ull* factor;
};

struct CsM_SequenceUll
{
    ull meret;
    ull* sequence;
};

ull FactorialInt(int);
long long CsM_GreatestProductInArrLong2D(long**, long, long, long);
long long CsM_GreatestProductInLineInt(int *, ull, ull);
int CsM_IsPalindromeInBaseUll(ull, ull);
ull CsM_LeastCommonMultiple(ull*, ull);
struct CsM_DynArrInt1D CsM_LexicographicPermutation(int, ull);
ull CsM_MaxUll(ull*, ull);
ull CsM_NumberOfDivisors(struct CsM_PrimeFactorsUll *ptr);
ull CsM_PowerUll(ull, ull);
struct CsM_PrimeFactorsUll CsM_PrimeFactorisationUll(ull, struct CsM_DynArrUll1D*);
void CsM_PrimeFactorisationUll_v2(struct CsM_PrimesUntilUll*, struct CsM_PrimeFactorsUll*);
void CsM_PrimesUntilUll(struct CsM_PrimesUntilUll*, ull);
void CsM_PrimesUntilUllExpand_v1(struct CsM_PrimesUntilUll*, ull);
void CsM_PrimesUntilUllGreaterThan3(struct CsM_PrimesUntilUll*);
struct CsM_DynArrCh1D CsM_RevProdOfRevChArr(struct CsM_DynArrCh1D, struct CsM_DynArrCh1D);
struct CsM_SequenceUll CsM_CollatzUll(ull);

#endif // CSM_MATH_H_INCLUDED

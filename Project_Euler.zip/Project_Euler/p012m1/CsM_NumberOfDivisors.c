#define __USE_MINGW_ANSI_STDIO 1
#include <stdio.h>
#include <stdlib.h>
#include "CsM_math.h"

/*
The function
 get a structure of the result of a number's prime factorisation and
 return the number of divisors of the number.
*/

ull CsM_NumberOfDivisors(struct CsM_PrimeFactorsUll *ptr)
{
    ull i;
    ull result = 1;

    //Printing input
    printf("CsM_NumberOfDivisors running.\n");
    printf(" ptr->number: %llu\n",ptr->number);
    printf(" primes^factors: ");
    for(i=0; i<ptr->meret; i++) printf("%llu^%d ",ptr->factor[i],ptr->power[i]);
    printf("\n");

    switch(ptr->number)
    {
    case 0:
        result = 1;
        break;
    case 1:
        result = 1;
        break;
    default:
        for(i=0; i<ptr->meret; i++) if(ptr->factor[i] > 1 && ptr->power[i] > 0) result *= (ptr->power[i]+1);
    }

    return result;
}

#ifndef CSM_MATH_H_INCLUDED
#define CSM_MATH_H_INCLUDED

#define ull unsigned long long

struct CsM_DynArrInt1D
{
    long long meret;
    int* numbers;
};

struct CsM_DynArrIntND
{
    long dimensions;
    long long *meret;
    int* numbers;
};

struct CsM_DynArrLld2D
{
    long long meret[1][2];
    long long* numbers;
};

struct CsM_DynArrUll1D
{
    long long meret;
    ull* numbers;
};

struct CsM_PrimeFactorsUll
{
    ull  meret;
    ull* factor;
    int* power;
};

struct CsM_SequenceUll
{
    ull* sequence;
    ull meret;
};

ull FactorialInt(int);
long long CsM_GreatestProductInArr2D(long**, long*, long*, long*);
long long CsM_GreatestProductInLineInt(int *, ull, ull);
int CsM_IsPalindromeInBaseUll(ull, ull);
ull CsM_LeastCommonMultiple(ull*, ull);
struct CsM_DynArrInt1D CsM_LexicographicPermutation(int, ull);
ull CsM_MaxUll(ull*, ull);
struct CsM_PrimeFactorsUll CsM_PrimeFactorisationUll(ull, ull*, ull);
void CsM_PrimesUntilUll(struct CsM_DynArrUll1D*, ull);
struct CsM_SequenceUll CsM_CollatzUll(ull);

#endif // CSM_MATH_H_INCLUDED

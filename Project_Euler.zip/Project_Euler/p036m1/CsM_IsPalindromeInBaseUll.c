#include <stdio.h>
#include "CsM_math.h"

int CsM_IsPalindromeInBaseUll(ull number, ull base)
{
    int tmp;
    int digit;
    ull divisor[2];
    char result;

    //printf("Settings:\n");
    tmp = 0;
    divisor[0] = 1;
    while(divisor[0]<=number)
    {
        divisor[0] *= base;
        tmp++;
    }
    //printf("divisor[0] = %d\n", divisor[0]);
    //printf("power = %d\n", power);
    tmp/=2;
    tmp--;
    //printf("power = %d\n", power);
    divisor[0] /= base;
    divisor[1] = base;
    result = 1;

    //printf("Calculations:\n");
    while(tmp>=0)
    {
        //printf("power = %d\n", power);
        digit = number/divisor[0];
        //printf("divisor[0] = %d\n", divisor[0]);
        //printf("divisor[1] = %d\n", divisor[1]);
        //printf("digit[0] = %d\n", digit[0]);
        //printf("digit[1] = %d\n", digit[1]);
        if(digit!=(number%divisor[1])/(divisor[1]/base))
        {
            result = 0;
            break;
        }
        tmp--;
        number -= digit*(divisor[0]+divisor[1]/base);
        divisor[0]/=base;
        divisor[1]*=base;
    }

    return result;
}

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "CsM_math.h"

int main () {

   int i = 1627;
   int j = 6721;

   printf("The numbers are anagrams: %d", CsM_AreAnagramNumbersInt(i, j));

   return 0;
}

#ifndef HIGHESTDIGITULL_H_INCLUDED
#define HIGHESTDIGITULL_H_INCLUDED

int HighestDigitULL(unsigned long long number)
{
    unsigned long long tentopower = 10;
    int digit = 0;


}

#endif // HIGHESTDIGITULL_H_INCLUDED

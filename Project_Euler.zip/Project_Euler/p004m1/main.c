/*
Task:
A palindromic number reads the same both ways. The largest palindrome made from the product of two 2-digit numbers is 9009 = 91 × 99.
Find the largest palindrome made from the product of two 3-digit numbers.
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

long *WalkInOfSquare(long, long, long, long);
char *CsM_IsPalindrome(char *);
char *CsM_ltoa(long);

int main()
{
    long i = 0, j = 0;
    long product = 0;
    long max = 0;
    char *ptr = "1236321";

    for(i = 999; i>100; i--)
    {
        for(j = i; j>99; j--)
        {
            product = i*j;
            ptr = CsM_ltoa(product);
            ptr = CsM_IsPalindrome(ptr);
            if(ptr!=NULL)
            {
                if(product>max)
                {
                    max = product;
                    printf("Palindrome: (i, j, product): %ld, %ld, %ld\n",i, j, product);
                }
            }
        }
    }


    return 0;
}

char *CsM_IsPalindrome(char *ptr)
{
    long size = 0;
    long i = 0;
    char *res = "";

    res = ptr;
    size = strlen(ptr);
    //printf("size: %d\n", size);

    while(i<size/2)
    {
        if(ptr[i]!=ptr[size-1-i])
        {
            res = NULL;
            break;
        }
        i++;
    }

    return res;
}

char *CsM_ltoa(long n)
{
    int digits = 0;
    char res[10] = {'\0','\0','\0','\0','\0','\0','\0','\0','\0','\0'};
    char *ret = NULL;
    char tmp = 0;
    short int i = 0;

    ret = res;
    digits = (int)log10(n)+1;

    while(i<digits)
    {
        tmp=n%10;
        res[i] = 48+tmp;
        n -= tmp;
        n /= 10;
        i++;
    }

    return ret;
}

long *WalkInOfSquare(long x_fr, long y_fr, long x_to, long y_to)
{
    static long layer = 0;
    static long number = 0;
    long result[3]= {0,0,0};
    long basevec[2];
    char dx = 0, dy = 0;
    long sqoflayer = 0;
    long *ptr = result;

    dx = x_to>x_fr?1:-1;
    dy = y_to>y_fr?1:-1;
    printf("dx = %ld, dy = %ld\n",dx, dy);
    basevec[0] = x_fr+layer*dx;
    basevec[1] = y_fr+layer*dy;
    sqoflayer = layer*layer;

    printf("\n");
    printf("number = %ld\n",number);
    /*
    printf("layer = %ld\n",layer);
    printf("basevec[0] = %ld\n",basevec[0]);
    printf("basevec[1] = %ld\n",basevec[1]);
    */

    /*
    if(!layer)
    {
        result[0] = x_fr;
        result[1] = y_fr;
    }
    else
    {
    */
    result[0] = basevec[0]-dx*((number+1)%2)*(layer-(number-sqoflayer)/2);
    //printf("%ld = %ld-(%ld)*((%ld+1)%2)*(%ld-(%ld-%ld)/2)\n",result[0], basevec[0], dx, number, layer, number, sqoflayer);
    result[1] = basevec[1]-dy*(number%2)*(layer-(number-sqoflayer)/2);
    //printf("%ld = %ld-(%ld)*(%ld%2)*(%ld-(%ld-%ld)/2)\n",result[1], basevec[1], dy, number, layer, number, sqoflayer);
    //}
    result[2] = layer;
    if(layer>abs(x_to-x_fr) || layer>abs(y_to-y_fr))
        ptr = NULL;

    number++;
    if(number == (layer+1)*(layer+1))
    {
        //printf("number == (layer+1)*(layer+1)\n");
        //printf("%ld == (%ld+1)*(%ld+1)\n",number, layer, layer);
        layer++;
        //printf("layer++ = %ld\n",layer);
        /*
        basevec[0] += dx;
        basevec[1] += dy;
        printf("basevec[0] = %ld\n",basevec[0]);
        printf("basevec[1] = %ld\n",basevec[1]);
        */
    }
    return ptr;
}

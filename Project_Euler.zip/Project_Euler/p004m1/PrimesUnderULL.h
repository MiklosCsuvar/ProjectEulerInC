#ifndef PRIMESUNDERULL_H_INCLUDED
#define PRIMESUNDERULL_H_INCLUDED

unsigned long long *PrimesUnderULL(unsigned long long* ptr,unsigned long long number)
{
    typedef unsigned long long ull;
    ull tmp;
    ull i;
    ull j;

    ptr = (ull *)realloc(ptr, 3*sizeof(ull));
    ptr[0] = 2;
    ptr[1] = 3;

    i = 2;
    j = 0;
    tmp = ptr[1] + 2;
    while(tmp<number)
    {
        while(j<i)
        {
            if(tmp%ptr[j]==0)
            {
                j = 0;
                tmp += 2;
                break;
            }
            else
            {
                j++;
            }
        }
        if(j==i)
        {
            ptr = (ull *)realloc(ptr, (i+1)*sizeof(ull));
            ptr[i++] = tmp;
            //i++;
            j = 0;
            tmp += 2;
        }
    }

    ptr =  (ull *)realloc(ptr, (i+1)*sizeof(ull));
    ptr[i] = '\0';

    return ptr;
}

#endif // PRIMESUNDERULL_H_INCLUDED

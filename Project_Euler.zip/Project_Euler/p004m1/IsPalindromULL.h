#ifndef ISPALINDROMULL_H_INCLUDED
#define ISPALINDROMULL_H_INCLUDED

unsigned long IsPalindromULL(unsigned long number)
{
    int numberofdigits;
    int tmp
}

#endif // ISPALINDROMULL_H_INCLUDED

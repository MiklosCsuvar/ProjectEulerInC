#include <stdio.h>
#include <stdlib.h>

int main()
{
    long int primes[10001];
    long int tmp;
    int i;
    int j;

    primes[0] = 2;
    primes[1] = 3;
    tmp = 5;

    i = 2;
    j = 0;
    while(i < 10001)
    {
        while(j < i)
        {
            if(tmp%primes[j])
            {
                j++;
            }
            else
            {
                tmp += 2;
                j = 0;
                continue;
            }
        }
        if(j==i)
        {
            primes[i] = tmp;
            printf("primes[%d] = %ld\n", i, primes[i]);
        }
        i++;
    }
    printf("10 001st prime number: %ld\n", primes[10000]);
    return 0;
}
